---
contract_id: earlier-cbu79-police-patrolmens-benevolent-association-080106-to-073110
label: "Patrolmen's Benevolent Association 2006-2010 Agreement (executed contract)"
expanded_label: "Patrolmen's Benevolent Association 2006-2010 Agreement (executed contract)"
term_start: 2006
term_end: 2010
source_pdf: "https://www.nyc.gov/assets/olr/downloads/pdf/collectivebargaining/cbu79-police-patrolmens-benevolent-association-080106-to-073110.pdf"
era: "earlier"  # older agreement, may be superseded in part by later documents
later_documents: ["pba-mou-2017-2025"]
pages: 39
ocr_pages: 39
pages_with_tables: 0
clauses: 86
---

# Patrolmen's Benevolent Association 2006-2010 Agreement (executed contract)

> **Earlier agreement, may be superseded.** Later documents keep parts of it in force and change others; where they conflict, the later document governs. Check them before relying on any clause: pba-mou-2017-2025.

**Term:** 2006–2010  
**Source PDF:** [https://www.nyc.gov/assets/olr/downloads/pdf/collectivebargaining/cbu79-police-patrolmens-benevolent-association-080106-to-073110.pdf](https://www.nyc.gov/assets/olr/downloads/pdf/collectivebargaining/cbu79-police-patrolmens-benevolent-association-080106-to-073110.pdf)  
**Pages:** 39 (39 OCR-reconstructed)  
**Clauses extracted:** 86

> This Markdown export is derived from the source PDF via `pdfplumber` text extraction with `ocrmac` (macOS Vision) OCR fallback for image-only pages. Tables were detected and rendered as pipe-delimited Markdown so column boundaries survive. Pages flagged `OCR` were reconstructed from page images and may contain minor character recognition errors — verify quotations against the source PDF before publishing.

---

## Contents

- [Letter: TERM](#page-1)
- [Cover memo from the Office of Labor Relations](#page-1)
- [Untitled section](#page-1)
- [SEP 0 3 2010](#page-1)
- [Article I — UNION RECOGNITION AND UNIT DESIGNATION](#page-2)
- [Article II — UNION SECURITY - DUES CHECKOFF](#page-3)
- [Article III — HOURS AND OVERTIME](#page-3)
- [Article IV — RECALL AFTER TOUR](#page-4)
- [Article V — COMPUTATION OF BENEFITS](#page-5)
- [Section 1 — Salary Rates](#page-6)
- [Section 2](#page-7)
- [Section 3 — General Wage Increase](#page-7)
- [Section 6 — Performance Compensation](#page-8)
- [Article VII — UNIFORM ALLOWANCE](#page-8)
- [Article VIII — LONGEVITY ADJUSTMENTS](#page-9)
- [Article IX — PAYMENT FOR HOLIDAY WORK](#page-11)
- [Section 1 — Sick Leave](#page-11)
- [Section 2 — Death-in-Family Leave](#page-11)
- [Section 3 — Military Leave](#page-11)
- [Section 4 — Special Excusals](#page-12)
- [Section 5 — Leave to attend hearings](#page-12)
- [Article XI — VACATIONS](#page-12)
- [IF APPOINTMENT](#page-12)
- [VACATION ALLOWANCE](#page-12)
- [IF APPOINTMENT](#page-13)
- [VACATION ALLOWANCE](#page-13)
- [IF APPOINTMENT](#page-13)
- [VACATION ALLOWANCE](#page-13)
- [IF APPOINTMENT](#page-14)
- [VACATION ALLOWANCE](#page-14)
- [Section 6 — Accrual of Vacation](#page-14)
- [Article XII — HEALTH AND HOSPITALIZATION BENEFITS](#page-15)
- [Section 4 — Health Care Flexible Spending Account,](#page-16)
- [Section 125 — of the IRS Code. Those employees eligible for New York City health plan](#page-16)
- [Article XIII — HEALTH AND WELFARE FUND](#page-17)
- [Article XIV — ANNUITY FUND](#page-18)
- [Article XV — SENIORITY](#page-18)
- [Section 1 — Safety Helmets](#page-19)
- [Section 2 — Parking Facilities](#page-19)
- [Section 3 — Maintenance of Facilities](#page-19)
- [Section 4 — Private Hospital Accommodations for Line-of-Duty Injuries](#page-19)
- [Section 5 — Information Exchange](#page-19)
- [Section 6 — Meal Areas](#page-20)
- [Section 7 — Personal Folder](#page-20)
- [Section 8 — Disciplinary Records](#page-20)
- [Section 9 — Disciplinary Procedure](#page-20)
- [Section 10 — Fixed Post Duty](#page-21)
- [Section 11 — Meal Scheduling](#page-21)
- [Section 12 — Lump Sum Payment](#page-21)
- [Section 13 — Interest Payments](#page-21)
- [Section 14 — Layoffs](#page-21)
- [Section 15 — Public Transportation](#page-22)
- [Section 16 — Funding Applications](#page-22)
- [Section 17 — Polygraphs](#page-22)
- [Section 18 — Seniority for Steady Tours](#page-22)
- [Section 19 — Mutual Exchange of Tours](#page-22)
- [Article XVII — UNION ACTIVITY](#page-23)
- [Article XVIII — NO DISCRIMINATION](#page-23)
- [Article XIX — NIGHT SHIFT DIFFERENTIAL](#page-23)
- [Article XX — OVERTME TRAVEL GUARANTEE](#page-24)
- [Section 5](#page-25)
- [Section 1 — Definitions.](#page-25)
- [STEPL](#page-27)
- [Article XXII — LINE-OF-DUTY DEATH BENEFIT](#page-29)
- [Article XXII — DEATH BENEFIT - UNUSED LEAVE AND COMPENSATORY TIME](#page-29)
- [Article XXIV — OPTIONAL WORK DURING VACATION](#page-30)
- [Article XXV — NO STRIKES](#page-30)
- [Article XXVI — BULLETIN BOARDS](#page-30)
- [ARTICLE AXVII - LABOR-MANAGEMENT COMMITTEE](#page-31)
- [Article XXVIII — NO WAIVER](#page-31)
- [Article XXIX — SAVING CLAUSE](#page-32)
- [Article XXX — FINANCIAL EMERGENCY ACT](#page-32)
- [ASSOCIATION OF THE CITY](#page-33)
- [ASSOCIATION OF THE CITY (continued)](#page-33)
- [DATE SUBMITTED TO THE](#page-33)
- [DATE SUBMITTED TO THE (continued)](#page-33)
- [DATE SUBMITTED TO THE (continued)](#page-33)
- [DATE SUBMITTED TO THE (continued)](#page-33)
- [Letter: PBA Agreement covering the period from August 1, 2006 through July 31, 2010](#page-34)
- [Letter: PBA Agreement covering the period from August 1, 2006 through July 31, 2010](#page-35)
- [DATE SUBMITTED TO THE (continued)](#page-35)
- [Letter: PBA Agreement covering the period from August 1, 2006 through July 31, 2010](#page-36)
- [Signatures](#page-37)
- [Letter: P.B.A. AGREEMENT FOR THẸ PERIOD](#page-38)
- [Signatures](#page-38)
- [Letter: P.B.A. AGREEMENT FOR THE PERIOD](#page-39)

---

<a id="page-1"></a>
## Page 1  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
TO:
FROM:
SUBJECT:
TERM:
HEADS OF CONCERNED CITY DEPARTMENTS AND AGENCIES
JAMES F. HANLEY, COMMISSIONER
EXECUTED CONTRACT: POLICE OFFICERS
Joe I eleg
AUGUST 1, 2006 TO JULY 31, 2010
Attached for your information and guidance is a copy of the executed contract entered
into by the Commissioner of Labor Relations on behalf of the City of New York and the
Patrolmen's Benevolent Association on behalf of the incumbents of positions listed in Article I
of said contract.
The contract incorporates terms of an agreement reached through collective bargaining
negotiations and related procedures.
DATED: SEP 0 3 2010
OFFICIAL
OPRICE OF LANOR RELATIONS
REGISTRATION
CONTRACT
ATO:
11001
DATE:
SEP 0 3 2010

<a id="page-2"></a>
## Page 2  ·  _OCR-reconstructed_

Patrolmen's Benevolent Association
2006 - 2010 Agreement
AGREEMENT made this 3rd day ofdeg 2010 by and between the City of New York
(hereinafter called "the City" or "the Employer"), acting by the Commissioner of Labor Relations,
and the Patrolmen's Benevolent Association of the City of New York, Inc. (hereinafter called
"the Union" or the "PBA"), for the four year period from August 1, 2006 to July 31, 2010. The
parties agree that this Agreement modifies the 2002-2004 collective bargaining agreement based
upon the May 19, 2008 arbitration award (t Arbitration Award) and August 21, 2008 Memorandum
of Understanding ("MOU"). Nothing in this agreement is intended to amend or modify the content
of the Arbitration Award or the MOU.
WHEREAS, the Police Officers employed by the City have duly designated the Union as their
exclusive bargaining representative for the purpose of collective bargaining with the City with
respect to wages, hours, and conditions of employment; and
WHEREAS, the Union and the City desire to cooperate in establishing conditions which will tend
to secure standards and conditions of employment consistent with the dignity of Police Officers, and
to provide methods for fair and peaceful adjustment of disputes that may arise between the Union
and the City; and
WHEREAS, as a result of collective bargaining, the parties have reached an agreement which they
desire to reduce to writing;
NOW, THEREFORE, it is mutually agreed as follows:
ARTICLE I - UNION RECOGNITION AND UNIT DESIGNATION
Section L.
The City recognizes the Union as the sole and exclusive collective bargaining representative for the
unit consisting of the employees of the New York City Police Department in the title of Police
Officer, except those detailed as First, Second or Third Grade Detectives.
Section 2.
Except as otherwise provided herein, for purposes of this Agreement, the terms "employee" and
"employees" or "Police Officer" shall be interchangeable and shall relate solely to employees in the
unit described in Section 1 of this Article.
11001

<a id="page-3"></a>
## Page 3  ·  _OCR-reconstructed_

ARTICLE II - UNION SECURITY - DUES CHECKOFF
Section 1.
All employees covered by this Agreement shall be free to become and remain members of the
Union in good standing
Section 2.
The Union shall have the exclusive right to the check-off and transmittal of dues in behalf of each
employee in the unit in accord with the Mayor's Executive Order No. 98, dated May 15, 1969,
entitled Regulations Regulating the Checkoff of Union Dues and in accord with the Mayor's
Executive Order No. 107, dated December 29, 1986, entitled "Regulations Governing Procedures
for Orderly Payroll Checkoff of Union Dues" and any executive orders which amend or supersede
said Executive Orders.
Section 3.
An employee may consent in writing to the authorization of the deduction of dues from the
employee's wages and to the designation of the Union as the recipient thereof. Such consent, if
given, shall be in the proper form, acceptable to the City, which bears the signature of the employee.
Section 4.
The parties agree to an agency shop to the extent permitted by applicable law as described in a
supplemental agreement hereby incorporated by reference into this Agreement.
ARTICLE III - HOURS AND OVERTIME
Section 1.
a.
b.
All ordered and/or authorized overtime in excess of forty (40) hours in any week or in
excess of the hours required of an employee by reason of the employee's regular duty chart
if a week's measurement is not appropriate, whether of an emergency nature or of a
non-emergency nature, shall be compensated for either by cash payment or compensatory
time off, at the rate of time and one-half, at the sole option of the employee. Such cash
payments or compensatory time off shall be computed on the basis of completed fifteen (15)
minute segments.
In order to preserve the intent and spirit of this Section on overtime compensation, there
shall be no rescheduling of days off and/or tours of duty. Notwithstanding anything to the
contrary contained herein, tours rescheduled for court appearances may begin at 8:00 A.M.
and shall continue for eight (8) hours and thirty-five (35) minutes. This restriction shall
apply both to the retrospective crediting of time off against hours already worked and to the
anticipatory reassignment of personnel to different days off and/or tours of duty.
11001

<a id="page-4"></a>
## Page 4  ·  _OCR-reconstructed_

In interpreting this Section, T.O.P. 336, promulgated on October 13, 1969, shall be
applicable. Notwithstanding anything to the contrary contained herein, the Department shall
not have the right to reschedule employees' tours of duty, except that the Department shall
have the right to reschedule employees' tours of duty on twenty occasions without payment
of pre-tour or post-tour overtime provided that the Department gives at least 24 hours notice
to the employees whose tours are to be rescheduled, and the Department may also
reschedule employees' tours of duty, without payment of pre-tour or post-tour overtime, for
New Year's Eve, St. Patrick's Day, Thanksgiving Day, Puerto Rican Day, West Indies Day
and Christopher Street Liberation Day, provided that the Department gives notice before
12:00 a.m. of the day(s) in question. The prohibition on rescheduling tours by more than
three (3) hours before or after normal starting time on the above named dates is also
eliminated.
Section 2.
a.
Notwithstanding anything to the contrary herein, employees assigned to the Detective
Bureau as so-called "white shield detectives" shall receive overtime compensation in accord
with the arbitrator's award in O.C.B. Docket No.A-148-70, dated September 8, 1971, unless
such compensation in cash is approved by the Borough Commander.
Effective February 22, 2010, Police Officers assigned to Detective Track Commands as so-
called "White Shield Detectives" shall work the same length of tour and number of
appearances as currently worked (i.e., in effect as of August 21, 2008) by Detectives in the
respective units to which they are assigned, as modified by this contract.
Section 3.
Overtime shall be computed on a monthly basis and shall be paid no later than six (6) weeks after
submission of the monthly report.
ARTICLE IV - RECALL AFTER TOUR
Section 1.
Any employee who is recalled to duty after having completed the employee's regular duty but four
(4) hours or more before the commencement of the employee's next regular tour and who is
released without having been assigned to duty prior to the commencement of said next regular tour
shall receive a minimum of four (4) hours' pay pursuant to the regular overtime provisions of this
Agreement, that is, in cash or compensatory time off at the sole option of the employee at the rate of
time and one-half (i.e., the equivalent of six (6) hours compensation at the employee's straight time
rate).
Section 2.
Any employee who is recalled to duty after having completed the employee's regular tour of duty
but six (6) hours or more before the commencement of the employee's next regular tour and who is
assigned to duty and then released from duty prior to the commencement of said next regular tour
shall receive a minimum of six (6) hours' pay pursuant to the regular overtime provisions of this
Agreement, that is, in cash or compensatory time off, at the employee's sole option, at the rate of
11001

<a id="page-5"></a>
## Page 5  ·  _OCR-reconstructed_

time and one-half (i.e., the equivalent of nine (9) hours' compensation at the employee's straight
time rate).
Section 3.
In the event the actual time spent on recall defined in Sections 1 and 2 of this Article extends
beyond the minimum periods provided herein, the employee shall receive pay pursuant to the
regular overtime provisions of this Agreement for the full period of time actually spent on such
Section 4.
Notwithstanding anything to the contrary provided in Sections 1 through 3 of this Article, any
employee who is recalled to duty after having completed the employee's regular tour of duty but
before the commencement of the next regular tour and who is assigned to duty or held without
assignment for the period which extends into the commencement of that next regular tour shall
receive pay pursuant to the regular overtime provisions of this Agreement only for the actual time
so assigned or held.
Section 5.
a.
Notwithstanding anything to the contrary in Sections 1 through 4 of this Article, any
employee who is recalled to duty after having completed the employee's regular tour of duty
but less than four (4) hours before the commencement of the employee's next regular tour
and who is released without having been assigned to duty prior to the commencement of that
next regular tour shall receive pay in cash or compensatory time off at the employee's sole
option, at the rate of time and one-half, for the actual time between the beginning of such
recall and the commencement of that next regular tour.
b.
Notwithstanding anything to the contrary in Sections 1 through 4 of this Article, any
employee who is recalled to duty after having completed the employee's regular tour of duty
but less than six (6) hours before the commencement of the employee's next regular tour and
who is assigned to duty and then released from duty prior to the commencement of that next
regular tour shall receive pay in cash or compensatory time off at the employee's sole
option, at the rate of time and one-half, for the actual time between the beginning of such
recall and the commencement of that next regular tour.
ARTICLE V - COMPUTATION OF BENEFITS
Since the basic forty-hour week has not been changed by this Agreement, any modification of the
nine (9) squad or any other standard charts and use of other tours shall not affect current standard
practice for the computation of compensation for holidays, vacation days, personal leave, annuity
fund contributions and other relevant benefits, which shall remain on the basis of an eight-hour
work day calculation, except as otherwise agreed to by the parties.
11001

<a id="page-6"></a>
## Page 6  ·  _OCR-reconstructed_

ARTICLE VI - SALARIES
Section 1. Salary Rates
During the term of this Agreement, the following basic amounts, which where specified include
both salary rates and longevity adjustments, shall prevail for employees:
a.
For Police Officers Hired prior to January 1, 2006
Grade-Service
First Grade
Effective
8/1/06
Effective
8/1/07
Effective
8/1/08
20 Years
15 Years
10 Years
5 Years
Basic
Second Grade
Third Grade
Fourth Grade
Fifth Grade
Sixth Grade
$74,767**
$73,742**
$72,742 R
$71,742*
$67,997
$54,234
$52,766
$50,377
$48,667
$46,396ł
$77,487**
$76,462**
$75,462 R
$74,462*
$70,717
$56,403
$54,877
$52,392
$50,614
$48,252
$80,912**
$79,846**
$78,806 R
$77,766*
$73,546
$58,659
$57,072
$54,488
$52,639
$50,182
For Police Officers Hired On/After January 1, 2006
Grade-Service
First Grade
Effective
8/1/06
Effective
8/1/07
Effective
8/1/08
20 Years
15 Years
10 Years
Basic (after 5.5 years, 5 year longevity
Basic (after 5.5 years)
Second Grade (with 5 year longevity)
Second Grade (after 4.5 years)
Third Grade (after 3.5 years)
Fourth Grade (after 2.5 years)
Fifth Grade (after 1.5 years)
Sixth Grade
$74,767**
$73,742**
$72,742 R
$71,742*
$67,997
$54,070*
$50,325
$47,357
$43,364
$38,799
$37,316
$77,487**
$76,462**
$75,462 R
$74,462*
$70,717
$56,083*
$52,338
$49,251
$45,099
$40,35l
$38,809
$80,912**
$79,846*ąłął
$78,806 R
$77,766*
$73,546
$58,652*
$54,432
$51,221
$46,903
$41,96łśąę
$40,361
Effective
8/1/09
$84,149**
$83,040**
$81,958 R
$80,877·š
$76,488
$61,005
$59,355
$56,668
$54,745
$52,189
Effective
8/1/09
$84,149**
$83,040**
$81,958 R
$80,877*ął
$76,488
$60,998*
$56,609
$53,27ął
$48,779
$43,644
$41,975
Effective
7/31/10
$85,379**
$84,270**
$83,188 R
$82,107*
$76,488
$61,005
$59,355
$56,668
$54,745
$52,189
Effective
7/31/10
$85,379**
$84,270**
$83,188 R
$82,107*
$76,488
$62,228*
$56,609
$53,270
$48,779
$43,644
$41,975
NOTE: The amounts indicated in this Section by asterisks (* and **) include the longevity
adjustments in Article VIll of this Agreement. The longevity adjustments in the amounts indicated
herein by a single asterisk (*) shall not be deemed to be part of salary for purposes of retirement
allowances unless at the time of retirement an employee paid at such rates shall have completed
twenty years of service; and the longevity adjustments in the amounts indicated herein by a double
asterisk (**) shall not be deemed to be part of salary for purposes of retirement allowances unless at
the time of retirement an employee paid at such rates shall have completed twenty-five years of
5
11001

<a id="page-7"></a>
## Page 7  ·  _OCR-reconstructed_

service; except that an employee who has more than twenty years, but less than twenty-five years of
service at the time of retirement shall have the adjusted rates indicated by a capital letter R deemed
to be part of salary for purposes of retirement allowances. In the event this provision is declared
invalid under the law, the parties shall reopen negotiations to resolve the issue of the increased cost
of changing the effective date of the pensionability of the above adjustments. Such negotiations
will be commenced forthwith. If no agreement is reached, an impasse may be declared and
subsequent mediation and the impasse proceeding, if any, shall in all respects be conducted on an
expedited basis.
Section 2
A laid off employee who is returned to service in the employee's former title or in a comparable
title from a preferred list, shall receive the basic salary rate that would have been received by the
employee had the employee never been laid off, up to a maximum of two (2) years of general salary
increases.
Section 3. General Wage Increase
a.
(i)
Effective August 1, 2006, Employees shall receive a rate increase of 4%.
(ii)
Effective August 1, 2007, Employees shall receive a rate increase of 4%.
(iii) Effective August 1, 2008, Employees shall receive a rate increase of 4%.
(IV)
Effective August 1, 2009, Employees shall receive a rate increase of 4%.
b.
The increases provided for in Section 3a above shall be calculated as follows:
(i)
The increase in Section 3a(i) shall be based upon the base rates (which shall include
salary or incremental schedules) of the applicable titles in effect on July 31, 2006;
(ії)
The increase in Section 3a(ii) shall be based upon the base rates (which shall include
salary or incremental schedules) of the applicable titles in effect on July 31, 2007;
(iii)
The increase in Section 3a(iii) shall be based upon the base rates (which shall include
salary or incremental schedules) of the applicable titles in effect on July 31, 2008;
and
(IV)
The increase in Section 3a(iv) shall be based upon the base rates (which shall include
salary or incremental schedules) of the applicable titles in effect on July 31, 2009.
The general increase provided in this Section 3 shall be applied to the base rates and salary
grades fixed for the applicable titles, except to the extent that the base rates and salary
grades are modified by Section 3 (d) of this provision.
Employees hired on or after January 1, 2006 shall be subject to the salary schedule set forth
in Section 1 (b) above.
11001

<a id="page-8"></a>
## Page 8  ·  _OCR-reconstructed_

Section 4.
Paychecks shall be delivered to commands by 3:00 p.m. on the Thursday preceding payday for
distribution after 3:00 p.m. on said Thursday.
Section S. Salary Itemization
The Department shall make available in convenient places in each precinct the appropriate payroll
work sheets for the purpose of enabling each employee to verify the salary components of the
employee's paycheck. The parties will review further the feasibility of otherwise advising each
employee of all payroll components along with the employee's paycheck.
Section 6. Performance Compensation
The City acknowledges that each of the uniformed services performs an important service that
reflects the diverse missions of the City's uniformed agencies. In order to reward service of an
outstanding, exceptional nature, each of the uniformed services will establish a performance
compensation program to recognize and reward such service, tailored to the unique missions of the
individual uniformed agency.
The parties agree that additional compensation may be paid to employees performing outstanding,
exemplary, difficult and/or unique assignments. The City will notify and discuss with each affected
union of its intent to pay such additional compensation and the individuals to be compensated.
The criteria for granting of performance-based compensation shall be based upon outstanding
performance in the work assigned, and/or performance of unique and difficult work.
The performance-based compensation payments provided for in this section shall be one-time, non-
recurring cash payments subject to applicable pension law. An employee can receive no more than
one payment annually.
These provisions shall not affect any existing productivity programs covered in any existing
collective bargaining agreements. Nor shall this provision be construed to waive any obligation of
the City to negotiate over future productivity programs as required by applicable law.
ARTICLE VII - UNIFORM ALLOWANCE
The City shall continue to pay to each employee a uniform allowance of $1,000.00 in accord with
existing standard procedures.
11001

<a id="page-9"></a>
## Page 9  ·  _OCR-reconstructed_

ARTICLE VIII - LONGEVITY ADJUSTMENTS
Section 1.
a.
(i)
b.
c.
Longevity adjustments shall continue to be paid as tollows:
Upon the completion of five years of service, a Police Officer shall
receive a longevity adjustment of $3,745.
(її)
Upon completion of ten years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,000.
Upon completion of fifteen years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,000.
(iv) Upon completion of twenty years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,025.
Effective July 31, 2008, Longevity adjustments shall be paid as follows:
(i)
Upon the completion of five years of service, a Police Officer shall
receive a longevity adjustment of $4,058.
(ii)
Upon completion of ten years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,000.
(iii)
Upon completion of fifteen years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,000.
(IV)
Upon completion of twenty years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,025.
Effective August 1, 2008, Longevity adjustments shall be paid as follows:
(I)
Upon the completion of five years of service, a Police Officer shall
receive a longevity adjustment of $4,220.
Upon completion of ten years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,040.
(V)
Upon completion of fifteen years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,040.
(VI)
Upon completion of twenty years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,066.
11001

<a id="page-10"></a>
## Page 10  ·  _OCR-reconstructed_

d.
e.
h.
i.
Effective August 1, 2009, Longevity adjustments shall be paid as follows:
(1)
Upon the completion of five years of service, a Police Officer shall
receive a longevity adjustment of $4,389.
(ії)
Upon completion of ten years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,081.
(111)
Upon completion of fifteen years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,082.
(IV)
Upon completion of twenty years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,109.
Effective July 31, 2010, Longevity adjustments shall be paid as follows:
(i)
Upon the completion of five years of service, a Police Officer shall
receive a longevity adjustment of $5,619.
(i¡)
Upon completion of ten years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,081.
(¡i)
Upon completion of fifteen years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,082.
(1V)
Upon completion of twenty years of service, a Police Officer First Grade shall
receive a longevity adjustment of an additional $1,109.
Effective July 31, 2008, each step of the longevity schedule shall be increased by any future
general wage increases, as compounded, as of the effective date of said increases, as
reflected in the above schedules.
The adjustment after the 5th and 10th years shall not be computed as salary for pension
purposes until after completing 20 years of service. The adjustment after the 15th and 20th
years shall not be computed as salary for pension purposes until after completion of 25 years
of service.
In the event this provision is declared invalid under the law, the parties shall reopen
negotiations to resolve the issue of the increased cost of changing the effective date of the
pensionability of the above adjustments. Such negotiations will be commenced forthwith
If no agreement is reached, an impasse may be declared and subsequent mediation and the
impasse proceeding, if any, shall in all respects be conducted on an expedited basis.
The calculation of night shift differential payments shall be based upon the same factors,
amounts and methodology as previously utilized.
ITHP and pension benefit calculations shall only include the amount of the longevity
payment that is pensionable.
9
11001

<a id="page-11"></a>
## Page 11  ·  _OCR-reconstructed_

Section 2.
The longevity adjustments provided in Section 1 of this Article VIII are reflected in the table of
salaries set forth in Article VI, Section 1 of this Agreement.
ARTICLE IX - PAYMENT FOR HOLIDAY WORK
Each employce shall receive eleven (11) paid holidays annually, payments for which shall be made
in accord with existing procedures.
ARTICLE X - LEAVES
Section 1. Sick Leave
a.
Each employee shall be entitled to leave with pay for the full period of any
incapacity due to illness, injury or mental or physical defect which is service-
connected pursuant to Section 14-122.1 of the Administrative Code.
(ii)
Each employee shall be entitled to leave with pay for the full period of any
incapacity due to illness, injury or mental or physical defect, whether or not
service-connected.
The Chief of Personnel shall consult with representatives of the Patrolmen's Benevolent
Association regarding the enforcement of the Sick Leave program in order to insure that
undue restrictions will not be placed upon employees. Departmental orders in connection
therewith shall be issued after consultation with the Patrolmen's Benevolent Association.
Section 2. Death-in-Family Leave
In the event of a death in an employee's immediate family and upon application to and approval of
the employee's commanding officer or supervisory head, an employee shall receive leave with pay
not exceeding four consecutive regular tours of duty. For the purposes of this Section, the phrase,
"immediate family", shall include any of the following: (a) a spouse, (b) a natural, foster or
step-parent, child, brother or sister, (c) a father-in-law or mother-in-law, or (d) any relative residing
in the employee's household. The commanding officer or supervisory head granting such leave
shall verify the death and relationship of the deceased. If the deceased was in the military service of
the United States at the time of death, the employee requesting leave shall produce the official
notice of death.
Section 3. Military Leave
Military leave not exceeding thirty (30) calendar days in any one calendar year and not exceeding
thirty (30) days in any one continuous period of such absence shall be granted with pay to any
employee requiring such leave to satisfy military obligations.
10
11001

<a id="page-12"></a>
## Page 12  ·  _OCR-reconstructed_

Section 4. Special Excusals
Excused time accorded to other personnel employed by the City under circumstances such as
excusals for the Dr. Martin Luther King, Jr., and the Senator Robert F. Kennedy funerals and the
Moon Landing Observation Day shall be granted equally to employees covered by this Agreement.
All compensating days off shall be subject to the exigencies of the Department.
Section 5. Leave to attend hearings
Individual employee grievants shall be granted leave with pay for such time as is necessary to
testify at arbitration hearings.
Leave with pay shall be granted to three (3) employees who are named grievants in a group
arbitration proceeding, for such time as is necessary for them to testify at their group arbitration
hearings.
Leave with pay for such time as is necessary to testify at their hearings shall be granted to
employees who, after final adjudication of proceedings under Section 210 paragraph 2h of the Civil
Service Law are determined not to have been in violation of Section 210.
ARTICLE XI - VACATIONS
Section 1.
The Department shall continue to provide the following authorized annual vacations for employces
hired prior to July 1, 1988:
b.
c.
Following the first 3 years of service (First Grade Police Officer): twenty-seven (27)
work days.
During the first 3 years of service (Second, Third, Fourth Grade and Probationary
Police Officer): twenty (20) work days.
During the calendar year in which the third anniversary of appointment occurs:
IF APPOINTMENT
DATE IS:
FROM
Jan. 1
Feb. 15
Apr. 16
June 16
July 16
Sept. 16
Nov. 16
Dec. 16
TO
Feb. 14
Apr. 15
June 15
July 15
Sept. 15
Nov. 15
Dec. 15
Dec. 31
VACATION ALLOWANCE
SHALL BE:
27 work days
26 work days
25 work days
24 work days
23 work days
22 work days
21 work days
20 work days
11
11001

<a id="page-13"></a>
## Page 13  ·  _OCR-reconstructed_

Section 2.
The Department shall provide the following authorized annual vacations for employees hired on or
after July 1, 1988 and before July 1, 2008:
a. Following the first 5 years of service: twenty-seven (27) work days.
b. During the first 5 years of service: twenty (20) work days.
c. During the calendar year in which the fifth anniversary of appointment occurs:
IF APPOINTMENT
DATE IS:
FROM
Jan. 1
Feb. 15
Apr. 16
June 16
July 16
Sept. 16
Nov. 16
Dec. 16
TO
Feb. 14
Apr. 15
June 15
July 15
Sept. 15
Nov. 15
Dec. 15
Dec. 31
VACATION ALLOWANCE
SHALL BE:
27 work days
26 work days
25 work days
24 work days
23 work days
22 work days
21 work days
20 work days
Section 3.
The Department shall provide the following authorized annual vacations for employees hired on or
after July 1, 2008:
a. Following the first 5 years of service: twenty-seven (27) work days.
b. During the first 5 years of service: ten (10) work days.
c. During the calendar year in which the fifth anniversary of appointment occurs:
IF APPOINTMENT
DATE IS:
FROM
Jan. 1
Feb. 15
Apr. 16
June 16
July 16
Sept. 16
Nov. 16
Dec. 16
TO
Feb. 14
Apr. 15
June 15
July 15
Sept. 15
Nov. 15
Dec. 15
Dec. 31
VACATION ALLOWANCE
SHALL BE:
27 work days
25 work days
22 work days
19 work days
16 work days
15 work days
12 work days
11 work days
12
11001

<a id="page-14"></a>
## Page 14  ·  _OCR-reconstructed_

Section 4.
Effective July 31, 2010, the Department shall provide the following authorized annual vacations for
employees hired on or after July 1, 2008:
a. Following the first 5 years of service: twenty-seven (27) work days.
b. During the first 2 years of service: ten (10) work days.
c. During the third, fourth and fifth years of service: thirteen (13) work days.
d. During the calendar year in which the fifth anniversary of appointment occurs:
IF APPOINTMENT
DATE IS:
FROM
Jan. 1
Feb. 15
Apr. 16
June 16
July 16
Sept. 16
Nov. 16
Dec. 16
TO
Feb. 14
Apr. 15
June 15 .
July 15
Sept. 15
Nov. 15
Dec. 15
Dec. 31
VACATION ALLOWANCE
SHALL BE:
27 work days
25 work days
23 work days
21 work days
18 work days
17 work days
15 work days
14 work days
Section 5.
Employees may select individual vacation days at the time vacations are picked, provided that the
maximum number of employees allowed to take such individual vacation days at any time shall be
2% of the Force and provided further that no employee may choose more than one of the following
holidays as an individual vacation day: Independence Day, Labor Day, Thanksgiving Day,
Christmas Day, and New Year's Day. Any employee who fails to select such individual vacation
days at the time the employee makes his regular vacation pick may select such individual vacation
days at a later time subject to the exigencies of the Department. Such individual vacation days shall
be treated as regular vacation picks.
Section 6. Accrual of Vacation
If the Police Department calls upon an employee in writing to forego the employee's vacation or
any part thereof that portion up to a maximum of three (3) weeks of vacation shall be carried over
until such time as it can be liquidated in the following calendar year subject to the following
conditions:
()
(2)
the selection of such vacation days shall be in the discretion of and subject to the
exigencies of the Department; and
the selection of such days in the following calendar year shall be made after the
regular vacation picks; and
13
11001

<a id="page-15"></a>
## Page 15  ·  _OCR-reconstructed_

(3)
the utilization of this vacation time shall be restricted to the months of January
through May and September through November.
It is the intention of the Police Department to allow an employee to request permission to accrue
vacation consistent with this provision and to grant such requests which are reasonable.
ARTICLE XII - HEALTH AND HOSPITALIZATION BENEFITS
Section 1.
The City shall continue to provide a fully paid choice of health and hospitalization insurance plans
for each employee, not to exceed 100% of the full cost of HIP-HMO on a category basis. There
will be an annual reopening period during the term of this Agreement for active employees to
exercise their choice among medical plans.
Section 2.
Retirees shall continue to have the option of changing their previous choice of Health Plans. This
option shall be:
(a) a one time choice;
(b) exercised only after one year of retirement; and
(c) can be exercised at any time without regard to contract periods.
The effective date of change to a new plan shall be the first day of the month three months after the
month in which the application has been received by the New York City Health Insurance Program.
Effective with the reopener period for Health Insurance subsequent to January 1, 1980 and every
two years thereafter, retirees shall have the option of changing their previous choice of health plans.
This option shall be exercised in accordance with procedures established by the Employer. The
Union will assume the responsibility of informing retirees of this option.
Section 3.
a.
Effective July 1, 1983 and thereafter, the City's cost for each employee and each
retiree under age 65 coverage shall be equalized at the Community-rated basic
HIP/HMO plan payment rate as approved by the State Department of Insurance on a
category basis of individual or family, e.g. the Blue Cross/GHICBP payment for
family coverage shall be equal to the HIP/HMO payment for family coverage.
If a replacement plan is offered to employees and retirees under age 65 which
exceeds the cost of the HIP/HMO equalization provided in Section 3a, the City shall
not bear the additional costs.
14
11001

<a id="page-16"></a>
## Page 16  ·  _OCR-reconstructed_

c.
The City (and other related Employers) shall continue to contribute on a City
employee benefits program-wide basis the additional amount of $35 million to
maintain the health insurance stabilization reserve fund which shall be used to
continue equalization and protect the integrity of health insurance benefits.
The health insurance stabilization reserve fund shall be used: to provide a sufficient
reserve; to maintain to the extent possible the current level of health insurance
benefits provided under the Blue Cross/GHI-CBP plan; and, if sufficient funds are
available, to fund new benefits.
The health insurance stabilization reserve fund shall be credited with the divisions or
reduced by the losses attributable to the Blue Cross/GHI-CBP plan.
d.
In the event that there is a Citywide or program-wide health insurance package
which exceeds the cost of the equalization and stabilization fund described above,
the parties may negotiate reconfiguration of this package which in no event will
provide for costs in excess of the total costs of this Agreement as set forth herein.
However, it is understood that the PBA will not be treated any better or any worse
than any other Union participating in the Citywide or Program-wide Health Program
with regard to increased health insurance costs.
Section 4. Health Care Flexible Spending Account,
a.
A flexible health care spending account shall be established after July 1993 pursuant to
Section 125 of the IRS Code. Those employees eligible for New York City health plan
coverage as defined on page 32, section 4(B) of the 1992 New York City Health Summary
Program Description shall be eligible to participate in the account. Participating employees
shall contribute at least $260 per year up to a maximum of $1,000 per year. Said
contribution minimum and maximum levels may be modified by the MLC Health Advisory
Committee based on experience of the plan. Any unfunded balance may be deducted from
final salary payments due an employee.
b.
Expenses of the account shall include but not be limited to deductibles, co-insurance,
co-payments, excess expenses beyond plan limits, physical exams and health related
transportation costs for vision, dental, medical and prescription drug plans where the
employee and dependents are covered. In no case will any of the above expenses include
those non-deductible expenses defined as non-deductible in IRS Publication 502.
c.
An administrative fee of $1.00 per week for the first year shall be charged for
participation in the program. An employee's participation in the account is irrevocable
during a plan year. At the close of the plan year any excess balance in an employee's
account will not be refunded.
15
11001

<a id="page-17"></a>
## Page 17  ·  _OCR-reconstructed_

ARTICLE XIII - HEALTH AND WELFARE FUND
Section 1.
a.
b.
c.
d.
Effective August 1, 2006, the City shall continue to contribute the pro-rata annual
amount of $1,400 for each employee for remittance to the Health and Welfare Fund of the
Patrolmen's Benevolent Association of the City of New York (* Welfare Fund) pursuant to
the terms of a supplemental agreement to be reached by the parties subject to the approval of
the Corporation Counsel. Effective July 31, 2008, the Employer's annual contractual
amount of contributions to the PBA Active and Retiree Health and Welfare Funds shall be
increased by any future general wage increases, as compounded, as of the effective date of
said increases, pursuant to the terms of a supplemental agreement to be reached by the
parties, which shall not be inconsistent with this Article, subject to the approval of the
Corporation Counsel as to form.
In accordance with the above paragraph, effective August 1, 2008, the pro-rata annual
amount shall be $1,456; effective August 1, 2009, the pro-rata annual amount shall be
$1,514.
Effective July 31, 2008, the Employer shall contribute a 3400 one-time lump sum payment
per retiree to the PBA Retiree Health and Welfare Fund pursuant to the terms of a
supplemental agreement to be reached by the parties subject to the approval of the
Corporation Counsel as to form.
Effective July 31, 2010, the Employer shall contribute a $100 one-time lump sum payment
per retiree to the PBA Retiree Health and Welfare Fund pursuant to the terms of a
supplemental agreement to be reached by the parties subject to the approval of the
Corporation Counsel as to form.
Pursuant to its commitment, the PBA will continue to provide benefits to employees'
domestic partners.
To the extent permitted by law, part of the amounts so contributed maybe applied to
maintain an appropriate legal services plan, pursuant to the terms of a supplemental
agreement between the parties as approved by the Corporation Counsel.
Effective August 1, L00o, employees who have been separated from service subsequent
to December 31, 1970, and who were covered by the Health and Weitare Fund of the
Patrolmen's Benevolent Association at the time of such separation pursuant to a
supplementary agreement between the City and the PBA shall continue to be so covered,
subject to the provisions of Sections 1(a), (b), and (c) hereof, on the same contributory basis
as incumbent employees. Contributions shall be made only for such time as said individuals
remain primary beneficiaries of the New York City Health Insurance Program and are
entitled to benefits paid for by the City through such Program.
16
11001

<a id="page-18"></a>
## Page 18  ·  _OCR-reconstructed_

e.
Civil Legal Representation Fund
Effective August 1, 2006, the City shall continue to contribute $75 per annum for each
active Employee to the Welfare Fund to establish a civil legal representation fund pursuant
to the terms of a supplemental agreement between the City and Union as approved by the
Corporation Counsel. While these funds shall be administered by the applicable Welfare
Fund, they are to be maintained in a separate account and shall not be commingled with the
other monies received by the Welfare Fund. Only the $75 provided above may be used for
civil legal representation. No additional monies from the Welfare Fund may be used for
civil legal representation.
f.
Such payments shall be made pro-rata by the City on a monthly basis.
Section 2.
Where an employee is suspended without pay for disciplinary reasons and is subsequently restored
to full pay status as of the date of the suspension, the employee shall receive full Health and
Weltare Fund contribution for the period of the suspension.
ARTICLE XIV - ANNUITY FUND
Section 1.
Effective August 1, 2006, the City shall continue to contribute for each employee, on a twenty eight
(28) day cycle basis, a pro-rata daily contribution for each working day for which such employee is
paid by the City which such amount shall not exceed $522.00 per annum for each employee in full
pay status in the prescribed twelve (12) month period. Contributions hereunder shall be remitted by
the City each twenty eight (28) to a mutually agreed upon annuity fund pursuant to the terms of a
supplemental agreement to be reached by the parties subject to the approval of the Corporation
Counsel.
Section 2.
Where an employee is suspended without pay for disciplinary reasons and is subsequently restored
to full pay status as of the effective date of the suspension, the employee shall receive full annuity
coverage for the period of the suspension.
ARTICLE XV - SENIORITY
The Department recognizes the importance of seniority in filling vacancies within a command and
shall make every effort to adhere to this policy, providing the senior applicant has the ability and
qualifications to perform the work involved. While consultation on such matters is permissible, the
final decision of the Department shall not be subject to the grievance procedure.
17
11001

<a id="page-19"></a>
## Page 19  ·  _OCR-reconstructed_

ARTICLE XVI - GENERAL
Section 1. Safety Helmets
The City agrees to furnish a safety helmet and equipment related thereto for each employee. Such
headgear shall conform to Police Department specifications in effect at the time of this Agreement.
Section 2. Parking Facilities
It is the intent of the Department to make available without liability to the City, City-owned
property and on-street location adjacent to, near or part of police stations or other command
locations, as parking facilities for the personal cars of employees. A single designated
representative of the Department and a single designated representative of the PBA will survey
locations in the vicinity of station houses to determine what space is available which could
reasonably be used for police parking and, where space exists, the Department and the PBA will
jointly request of the appropriate City agency designation of such locations. This expressed intent
of the Department does not imply any obligation or commitment on the part of the City or the
Department to make available any such location or parking facilities. Where such property is
provided and so designated for this purpose, the City shall not be obligated to improve the same, nor
to maintain it for parking. The City need not continue to provide such property for parking when
the City, in its discretion, decides to make a different use of it.
All inquires or complaints from employees concerning the subject matter or application of this
section shall be referred directly to the PBA for investigation and review. The PBA shall screen
and thereafter shall present only those inquiries or complaints which it believes are justified to the
Commanding Officer of the Office of Labor Relations of the Police Department, or the
Commanding Officer's designee, for discussion and possible adjustment.
This Section shall not be subject to the grievance procedure.
Section 3. Maintenance of Facilities
All commands and other Departmental places of assignment shall have adequate heating, hot water
and sanitary facilities. The Union shall give notice to the Department of any failure to maintain
these conditions. If not corrected by the Department within a reasonable time, the Union may
commence a grievance at Step 3 of the grievance procedure concerning that failure.
Section 4. Private Hospital Accommodations for Line-of-Duty Injuries
It is the intent of the City to use its best efforts to secure private room accommodations in a hospital
for employees injured in the line of duty. This Section shall not be subject to the grievance
procedure.
Section 5. Information Exchange
a.
The Department will provide the Union with a copy of all Orders, Department Bulletins,
"Open Door" issues, and press releases. The details of delivery shall be worked out between
the parties.
18
11001

<a id="page-20"></a>
## Page 20  ·  _OCR-reconstructed_

The Department will provide to the Union on a semi-annual basis a computer printout
containing names and addresses of employees, listed alphabetically.
The Union will provide the Department with a copy of Union publications, bulletins and
press releases.
Section 6. Meal Areas
A representative of the Department and a representative of the PBA will meet to determine an
adequate meal area for employees within each command and other Departmental places of
assignment. This does not contemplate rebuilding or extensive remodeling.
Section 7. Personal Folder
a.
The Personnel Bureau will provide the Union with a list of categories of items included
in the Personal Folder with an indication of those confidential items which an employee is
not permitted to review.
Employees may view their folders on normal business days between the hours of 9
A.M. and 5 P.M. by appearing in person at the Employee Management Division, Personnel
Bureau, 10th Floor, Police Headquarters. To avoid delay, employees should call the
Employee Management Division at least one day in advance.
The Department will, upon written request to the Chief of Personnel by the individual
employee, remove from the Personal Folder investigative reports which, upon completion of
the investigation, are classified "exonerated" and/or "unfounded."
Section 8. Disciplinary Records
Where an employee has been charged with a "Schedule A" violation as listed in Patrol Guide 118-2
and such case is heard in the Trial Room and disposition of the charge at trial or on review or appeal
therefrom is other than "guilty", the employee concerned may, after 2 years from such disposition,
petition the Police Commissioner for a review for the purpose of expunging the record of the case.
Such review will be conducted by a board composed of the Deputy Commissioner - Trials,
Department Advocate, and the Chief of Personnel, or their designees. The Board will make a
recommendation to the Police Commissioner. The employee concerned will be notified of the final
decision of the Police Commissioner by the Deputy Commissioner - Trials.
Section 9. Disciplinary Procedure
The parties, through a joint subcommittee, shall develop procedures to insure that:
a.
All disciplinary charges shall be brought in a timely fashion pursuant to the current
departmental regulations.
b.
Departmental trials shall be held as promptly as possible, utilizing additional hearing
personnel.
19
11001

<a id="page-21"></a>
## Page 21  ·  _OCR-reconstructed_

Reimbursement shall be made for any period of suspension in excess of any penalty
ultimately levied.
Section 10. Fixed Post Duty
A commanding officer may limit fixed post duty for a single employee to a single four-hour period.
Section 11. Meal Scheduling
Employees shall not be assigned meals as a matter of practice during either the first hour and
one-half or last hour and one-half of their tours. In cases of emergency this practice may be altered.
Section 12. Lump Sum Payment
Where an employee has an entitlement to accrued annual leave and/or compensatory time, and the
City's fiscal condition requires employees who are terminated, laid off or who choose to retire in
lieu of layoff to be removed from the payroll on or before a specific date, or where an employee
reaches the mandatory retirement age, the employer shall provide the monetary value of
accumulated and unused annual leave and/or compensatory time allowances standing to the
employee's credit in a lump sum. Such payment shall be in accordance with the provisions of
Executive Order 30, dated June 24, 1975.
Where an employee has an entitlement to terminal leave and the City's fiscal situation requires that
employees who are terminated, laid off, or retired be removed from the payroll on or before a
specific date, or where an employee reaches the mandatory retirement age, the employer shall
provide a monetary lump sum payment for terminal leave in accordance with the provisions of
Executive Order 31, dated June 24, 1975.
Section 13. Interest Payments
Interest on wage increases shall accrue at the rate of three percent (3%) per annum from one
hundred-twenty (120) days after execution of this Agreement or one hundred-twenty (120) days
after the effective date of the increase, whichever is later, to the date of actual payment. Interest on
longevity and step-up increments, differentials and holiday pay shall accrue at the rate of three
percent (3 %) per annum from one hundred-twenty (120) days tollowing its earning or one
hundred-twenty (120) days after the execution of this Agreement, whichever is later, to the date of
actual payment. Interest on overtime pay shall accrue at the rate of three percent (3 %) per annum
from one hundred-twenty (120) days following its earning or one hundred-twenty (120) days
following the employee's submission of an overtime report, whichever is later. Interest accrued
pursuant to this paragraph shall be payable only if the amount of interest due to an individual
employee exceeds five dollars ($S).
Section 14. Layoffs
Where layoffs are scheduled the following procedure shall be used:
a.
Notice shall be provided to the appropriate Union not less than 30 days before the
effective dates of such projected layoffs.
20
11001

<a id="page-22"></a>
## Page 22  ·  _OCR-reconstructed_

Within such 30-day period designated representatives of the Employer will meet and
confer with the designated representatives of the appropriate Union with the objective of
considering feasible alternatives to all or part of such scheduled layoffs, including but not
limited to (a) the transfer of employees to agencies with retraining, if necessary, consistent
with Civil Service Law but without regard to Civil Service title, (b) the use of Federal and
State funds whenever possible to retain or re-employ employees scheduled for layoff, (c) the
elimination or reduction of the amount of work contracted out to independent contractors
and (d) encouragement of early retirement and the expediting of the processing of retirement
applications.
When a layoff occurs, the Department will provide the Union with a list of employees who
are on a preferred list with the original date of appointment utilized for the purpose of such
layoff.
Section 15. Public Transportation
The City and the PBA will use their best efforts to effect free transportation on buses and subways
for police officers.
Section 16. Funding Applications
The City shall continue to apply for Federal funding to hire additional police officers.
Section 17. Polygraphs
The current practice concerning the use of polygraphs in internal investigations shall be maintained
during the term of this Agreement.
Section 18. Seniority for Steady Tours
Operation Order #105 dated 11/6/78 shall be modified to delete all references to seniority as the
basis for assignment to steady tours. Police Officers who are currently assigned to steady late tours
pursuant to the old clause will be "grandfathered," but subject to the current rules on removal for
cause. Volunteers for steady late tours shall be solicited in the first instance by seniority with the
commanding officer having the discretion to choose volunteers. If the most senior volunteer is not
chosen, the officer may appeal to the First Deputy Commissioner or his designee whose decision
shall be binding and not subject to the grievance and arbitration procedure.
Section 19. Mutual Exchange of Tours
a.
Commanding Officers shall permit members performing similar duties to exchange tours
voluntarily when there is no interference with police service.
b.
Members are not permitted to exchange tours so that they would perform two (2)
consecutive tours.
C.
This procedure shall be incorporated into the Patrol Guide.
21
11001

<a id="page-23"></a>
## Page 23  ·  _OCR-reconstructed_

ARTICLE XVII - UNION ACTIVITY
Section 1.
With respect to time spent by Union officials and representatives in the conduct of labor relations,
the provisions of Mayor's Executive Order No. 75, dated March 22, 1973, or any other applicable
Executive Order or local law, or as otherwise provided in this Agreement shall be deemed
applicable. No employee shall otherwise engage in Union activities during the time the employee is
assigned to the employee's regular duties.
Section 2.
PBA Trustees and delegates shall be recognized as representatives of the PBA within their
respective territories and commands. For the purpose of attending the regular scheduled monthly
delegate meeting, PBA delegates shall be assigned to the second platoon and excused from duty for
that day. In the event the delegate so assigned to the second platoon is unable to attend said
monthly delegate meeting because of illness which requires remaining at home or hospitalization, or
absence from the New York metropolitan area on leave or by assignment, or required court
appearance, then and only then will a designated alternate delegate be excused from duty as spelled
out in this Section. The Union will provide the City with a list of those attending each such
meeting, which shall be the basis for their payment.
Section 3.
The parties shall explore a further clarification of Departmental rules and procedures to enable PBA
delegates and officers to represent properly the interests of employees. An appropriate
Departmental order in this regard shall be issued.
ARTICLE XVIII - NO DISCRIMINATION
In accord with applicable law, there shall be no discrimination by the City against any employee
because of Union activity.
ARTICLE XIX - NIGHT SHIFT DIFFERENTIAL
a.
There shall be a 10% night shift differential effective January 1, 1971 applicable to all
employees assigned to rotating tours of duty for all work actually performed between the
hours of 4:00 p.m. and 8:00 a.m. There shall be a 10% night shift differential effective
January 1, 1971 applicable to all other employees for all work actually performed between
the hours of 4:00 p.m. and 8:00 a.m., provided that more than one hour is actually worked
after 4:00 p.m. and before 8:00 a.m.
Where overtime compensation is to be calculated for tours in the regular duty chart, the
overtime calculation shall be based on the rate paid for the tour to which the overtime is
attached; for tours not in the regular duty chart, the overtime calculation shall be based on
the rate paid for half or more of the hours of the tour to which the overtime is attached.
22
11001

<a id="page-24"></a>
## Page 24  ·  _OCR-reconstructed_

C.
For all employees hired after June 30, 1991:
2.
No night shift differential shall be paid to those employees while they are
assigned to the Police Academy as a recruit or for Recruit Training.
Thereafter, 55% of the night shift differential as described in paragraph "a" above
earned by a similarly situated Police Officer hired prior to July 1, 1991 shall be paid
until the employee reaches First Grade after five years. Effective January 1, 1995,
the rates paid to Police Officers shall equal the ratio between the Police Officer's
base salary and the Basic First Grade salary in effect at the time. Those rates shall be
as follows:
Second Grade: 78%
Third Grade: 75%
Fourth Grade: 71%
Fifth Grade: 68%
Sixth Grade: 64%
ARTICLE XX - OVERTME TRAVEL GUARANTEE
Section 1.
The assignment of an employee to a post not within the employee's permanent command shall in
the first instance be accomplished so that the assignment originates and terminates within such
employee's permanent command and within the employee's regular tour of duty.
Section 2.
Overtime travel guarantee compensation shall continue to be paid as follows:
a.
In the event that an employee is assigned to a post outside the employee's permanent
command and is required to report -at such post at the start of the employee's regular
tour of duty, the employee shall accrue an allowance for travel to the post to assigned
post at the rate of time and one-half for forty-five (45) minutes of travel time if the
assigned post is within the same patrol borough as the employee's permanent
command or at the rate of time and one-half for 1-1/4 hours if the assigned post is in
a different patrol borough from that of the employee's permanent command.
b.
In the event that an employee is assigned to a post outside the employee's permanent
command and cannot return to the permanent command within the regular tour of
duty, the employee shall accrue an allowance for travel to the permanent command
at the same rate as stated in Subsection 2a of this Article XX.
Section 3.
The overtime accrued pursuant to this Article for any one day shall be taken by the employee at the
employee's sole option either all in cash or all in compensatory time off.
23
11001

<a id="page-25"></a>
## Page 25  ·  _OCR-reconstructed_

Section 4.
In the administration of the provisions of this Article the arbitrator's award in OCB Docket No. A-
114-70 shall be applicable except that the provisions of this Article shall apply to employees
assigned to the Tactical Patrol Unit.
Section 5
a.
All claims for payment of compensatory time off which is earned as provided in Article
b.
c.
d.
payment is earned will be granted the appropriate compensatory time off only for claims
under Article XX.
If a request for payment is timely submitted and rejected by the Police Department, the
grievant shall have 90 days from the date of receipt of a written rejection notice to file a
grievance pursuant to Article XXI.
The above clarification shall apply only to Article XX claims earned on April 1, 1977
or thereafter.
This clarification applies to a grievance brought under this collective bargaining
contract only. It has no applicability to any other legal remedy which an individual may
have.
ARTICLE XXI - GRIEVANCE AND ARBITRATION PROCEDURE
Section 1. Definitions.
a.
b.
For the purpose of this Agreement, the term "grievance" shall mean:
a claimed violation, misinterpretation or inequitable application of the provisions
of this Agreement;
a claimed violation, misinterpretation or misapplication of the written rules,
regulations or procedures of the Police Department affecting terms and conditions of
employment, provided that, except as otherwise provided in this Section la, the term
"grievance" shall not include disciplinary matters;
3.
a claimed improper holding of an open-competitive rather than a promotion
examination;
4.
a claimed assignment of the grievant to duties substantially different from those
stated in the grievant's job title specification.
For the purposes of this Agreement, the term "Commanding Officer" shall mean the
immediate Commanding Officer of the aggrieved employee.
24
1100M

<a id="page-26"></a>
## Page 26  ·  _OCR-reconstructed_

c.
For the purposes of this Agreement, the term "Reviewing Officer" shall mean the
superior officer in charge of the next higher command or level above a Commanding
Officer.
For the purposes of this Agreement, the term "Board" shall mean the Personnel
Grievance Board to be composed of three (3) members, as follows: a Deputy Commissioner
or other designee of the Police Commissioner, who shall be Chairman of the Board, the
Chief of the Department or the Chief of the Department's designee, and the President of the
Union or the President's designee.
e.
For the purposes of this Agreement, the term "grievant" shall mean an employee or
group of employees asserting a grievance or the Union or both, as the context requires.
Section 2.
The availability of the grievance or arbitration procedure shall not justify a failure to follow orders.
Section 3.
a.
Every grievant shall have the right to present a grievance in accord with the procedure
provided herein free from coercion, interference, restraint or reprisal.
The informal resolution of differences or grievances is urged and encouraged at all
levels of supervision.
c.
Commanding Officers and Reviewing Officers shall promptly consider grievances presented
to them and, within the scope of their authority take such necessary action as is required
herein.
Commanding Officers, Reviewing Officers and members of the Personnel Grievance Board
shall consider objectively the merits of grievances with due consideration to the harmonious
interrelationship that is sought to be achieved among all members of the force and for the
good of the Police Department.
Any employee may present the employee's own grievance through the first four steps of
the grievance procedure either individually (with the aid of the employee's own counsel if
the employee so chooses), or through the Union, provided, however, that the Union shall
have the right to have a representative present at each step of the grievance procedure.
Section 4.
Under the grievance procedure herein a grievance must be initiated within 90 days following the
date on which the grievance arose or the date on which the grievant should reasonably have learned
of the grievance or the execution date of this Agreement, whichever date is the latest. Grievances
shall be processed according to the following procedure:
25
11001

<a id="page-27"></a>
## Page 27  ·  _OCR-reconstructed_

STEPL
A grievant shall present the grievance to the Commanding Officer either orally or in writing. The
Commanding Officer shall carefully consider the matter, make a decision thereon and advise the
grievant of the decision within five (5) days of the grievance's submission.
STEP I.
If the grievance is not satisfactorily adjusted at Step I, the grievant may seek the following review
within ten days after receipt of the Step I decision. The grievant shall reduce the grievance to
writing on Form P.D. 158-151 (in triplicate), setting forth a concise statement of the grievance and
the results of the proceedings at Step I. The grievant shall forward two copies to the appropriate
Reviewing Officer and retain one copy for personal use. The Reviewing Officer shall forward one
copy to the Commanding Officer, requesting the Commanding Officer's comments. The
Reviewing Officer shall carefully consider said grievance, make a determination, and notify the
grievant and the Commanding Officer of the Reviewing Officer's decision within ten (10) days
following receipt of the grievance.
STEP III.
If the grievance is still not satisfactorily adjusted, the grievant may, not later than ten days after
notification of the Reviewing Officer's decision, seek further review as follows:
The grievance shall be submitted to the Chairman of the Personnel Grievance Board on the
grievance form supplied by the Office of Labor Relations of the Police Department. The Board
shall forward one copy to the Reviewing Officer, requesting the Reviewing Officer's comments
thereon. The Personnel Grievance Board shall meet at least once a month on a date designated by
the Chairman. At each meeting, the Board shall consider all grievances which, at least five days
prior to such meeting, have been properly referred to the Board. The grievant may choose to have
the grievant's representatives present at the meeting, at which time oral and written statements may
be presented.
The Board shall carefully consider said grievance, make a determination and notify the grievant, the
Commanding Officer and the Reviewing Officer, in writing, of its decision within seven days after
the meeting at which the grievance is considered.
It is understood and agreed by and between the parties that there are certain grievable disputes
which are of a Department level or of such scope as to make adjustments at Step I or Step II of the
grievance procedure impracticable, and, therefore, such grievances may be instituted at Step III of
the grievance procedure by filing the required written statement of the grievance directly with the
Chairman of the Personnel Grievance Board; the Chairman or Chairman's designee shall convene a
meeting of the Board within five (5) working days following receipt of the grievance, and the Board
shall render its decision within five (5) working days following that meeting.
STEP IV.
Where the grievance is not satisfactorily adjusted at Step III, the grievant may refer the grievance,
not later than thirty (30) calendar days after notification of the Board's decision, to the Police
Commissioner for determination; and the Police Commissioner shall make a determination within
26
11001

<a id="page-28"></a>
## Page 28  ·  _OCR-reconstructed_

ten (10) working days following receipt of the grievance. This determination shall be made after
appropriate consultation with any or all parties to the grievance, including the Chairman of the
Board and/or the Board members; and copies shall be sent to the grievant and the Union.
Grievances which affect substantial numbers of employees may be compressed by elimination of
the fourth Step of the grievance procedure.
Section S
At every step of these procedures, the grievant and the officer considering the grievance shall work
for a satisfactory adjustment. At any step, the Commanding Officer, the Reviewing Officer, and the
Board shall have the right to summon the grievant and any and all persons considered necessary to
the equitable adjustment of the grievance. Proceedings shall be informal. The Chairman of the
Personnel Grievance Board shall take such steps to implement the provisions concerning grievances
as are necessary for the proper and effective operation of the procedures provided for herein. The
Chairman shall resolve questions as to jurisdictional responsibility of Commanding Officers and
Reviewing Officers and shall work out the operational details of the program. For these purposes,
the Chairman shall issue orders and instructions through the Chief of Department not inconsistent
with the provisions of this Article.
Section 6.
The grievance procedure established hereinbefore is designed to operate within the framework of,
and is not intended to abolish or supersede, existing rules and procedures providing for additional
methods of redress. These include, but are not limited to, the existing rights of a grievant to request
an interview with the Police Commissioner.
Section 7.
Any or all of the foregoing grievance steps may be waived by the written consent of both parties.
Section 8.
Within twenty (20) days following receipt of the Police. Commissioner's Step IV decision, the
Union shall have the right to bring grievances unresolved at Step IV to impartial arbitration
pursuant to the New York City Collective Bargaining Law and the Consolidated Rules of the New
York City Office of Collective Bargaining. In addition, upon ten (10) days' written notice to the.
Union, the City shall have the right to bring directly to arbitration any dispute between the parties
concerning any matter defined as a "grievance" herein. The City shall commence such arbitration
by submitting a written request therefor to the Office of Collective Bargaining, with a copy to the
Union; and the matter shall proceed pursuant to the Consolidated Rules of the Office of Collective
Bargaining.
A permanent rotating Panel of a minimum of five (5) Arbitrators shall be established, drawn from
the official panel of the Office of Collective Bargaining, as agreed to by both parties. The members
of the Panel shall be assigned on a rotating basis to arbitrate all grievances under this Section.
27
11002

<a id="page-29"></a>
## Page 29  ·  _OCR-reconstructed_

The assigned Arbitrator shall hold a hearing at a time and place convenient to the parties and a
transcript shall be taken unless the taking of a transcript is waived by both parties. The arbitrator
shall attempt to issue an award within ten (10) days after the completion of the hearing.
The City and the Union shall each pay 50% of the fees and expenses of the Arbitrator and of all
other expenses incidental to such arbitration. The costs of one copy for each party and one copy for
the Arbitrator of the transcripts shall be borne equally by the parties.
Section 9.
In case of grievances falling within Sections I(a)(1), 1(a)(2), or 1(a)(3) of this Article, the
arbitrator's decision, and order or award (if any), shall be limited to the application and
interpretation of the collective bargaining Agreement, rule, regulation, procedure, order or job title
specification involved, and the Arbitrator shall not add to, subtract from, or modify any such
Agreement, rule, regulation, procedure, order or job title specification. An Arbitrator's award shall
be final and binding and enforceable in any appropriate tribunal in accord with Article Seventy-Five
of the Civil Practice Law and Rules, except that awards as to grievances concerning assignment of
the grievant to duties substantially different from those stated in the grievant's job title specification
or the use of an open-competitive rather than promotional examination, shall be final and binding
and enforceable only to the extent permitted by law. An Arbitrator may provide for and direct such
relief as the Arbitrator determines to be necessary and proper, subject to the limitation set forth
above and any applicable limitations of law.
Section 10.
The time limits contained in this Article may be modified by mutual agreement. In the event that
the Department fails to comply with the time limits prescribed herein, the grievance may be
advanced to the next step.
ARTICLE XXII - LINE-OF-DUTY DEATH BENEFIT
In the event an employee dies because of a line-of-duty injury received during the actual and proper
performance of police service relating to the alleged or actual commission of an unlawful act, or
directly resulting from a characteristic hazard of police duty, through no fault of the employee's
own, a payment of $25,000 shall be made from funds other than those of the Retirement System in
addition to any other payment which may be made as a result of such death. Such payment shall be
made to the beneficiary designated under the Retirement System or, if no beneficiary is so
designated, to the estate of the deceased.
ARTICLE XXII - DEATH BENEFIT - UNUSED LEAVE AND COMPENSATORY TIME
If an employee dies while employed by the City, the employee's beneficiary designated under the
Retirement System or, if no beneficiary is so designated, the deceased's estate shall receive
payment in cash for the following as a death benefit:
28
11001

<a id="page-30"></a>
## Page 30  ·  _OCR-reconstructed_

a.
b.
All unused accrued leave up to a maximum of 54 dayằ_credit.
All unused accrued compensatory time earned subsequent to January 1, 1971 which is
verifiable by official Department records up to a maximum of two hundred (200) hours.
ARTICLE XXIV - OPTIONAL WORK DURING VACATION
Section 1.
Any employee may volunteer to work for one five-day period per year during such employee's
vacation leave. Whether the volunteer will be assigned to duty is within the discretion of the
Department. If assigned to such duty, the assignment shall be at the discretion of the Department to
any regular platoon in any one command for the entire five (5) day period. No employee shall be
discriminated against in the application of this Section because the employee is in the last year of
service.
Section 2.
An employee who so volunteers shall be compensated at the employee's regular straight time rate of
pay for all work performed during the employee's assigned platoon's regular hours of work. Except
as otherwise provided in this Article, all other provisions of this Agreement shall be applicable to
work so performed.
Section 3.
Contributions under Article XIII (Health and Welfare Fund) and Article XIV (Annuity Fund) of this
Agreement shall not be paid for work performed pursuant to this Article.
Section 4.
For the purposes of Article XX, (Overtime Travel Guarantee) of this Agreement, the command to
which an employee is so assigned for the five (5) day period shall be deemed that employee's
permanent command.
ARTICLE XXV - NO STRIKES
In accord with applicable law, neither the Union nor any employee shall induce or engage in any
strikes, slowdowns, work stoppages, or mass absenteeism, or induce any mass resignations during
the term of this Agreement.
ARTICLE XXVI - BULLETIN BOARDS
The Union may post notices on bulletin boards in places and locations where notices are usually
posted by the Employer for employees to read. All notices shall be on Union stationary, shall be
used to only notify employees of matters pertaining to Union affairs, and shall not contain any
derogatory or inflammatory statements concerning the City, the Department, or personnel employed
by either entity.
29
11002

<a id="page-31"></a>
## Page 31  ·  _OCR-reconstructed_

ARTICLE AXVII - LABOR-MANAGEMENT COMMITTEE
Section 1.
The City and the Union, having recognized that cooperation between management and employees is
indispensable to the accomplishment of sound and harmonious labor relations, shall jointly maintain
and support a labor-management committee.
Section 2.
The labor-management committee shall consider and may recommend to the Police Commissioner
changes in the working conditions of the employees, including, but not limited, to the following
subjects: the adequate levels of Police coverage to ensure the safety of employees on duty; an
excusal policy for employees appearing in court after the midnight tour. Matters subject to the
grievance procedure shall not be appropriate items for consideration by the labor-management
committee.
Section 3.
The labor-management committee shall consist of six (6) members who shall serve for the term of
this Agreement. The Union shall designate three (3) members and the Police Commissioner shall
designate three (3) members. Vacancies shall be filled by the appointing party for the balance of
the term to be served. Each member may designate one (1) alternate. The committee shall select a
chairman from among its members at each meeting. The chairmanship of the committee shall
alternate between the members designated by the Police Commissioner and the members designated
by the Union. A quorum shall consist of a majority of the total membership of the committee. The
committee shall make its recommendation to the Police Commissioner in writing.
Section 4.
The labor-management committee shall meet at the call of either the Union members or the City
members at times mutually agreeable to both parties. At least one (1) week in advance of a meeting
the party calling the meeting shall provide to the other party a written agenda of matters to be
discussed. Minutes shall be kept and copies supplied to all members of the committee.
ARTICLE XXVIII - NO WAIVER
Except as otherwise provided in this Agreement, the failure to enforce any provision of this
Agreement shall not be deemed a waiver thereof. This Agreement is not intended and shall not be
construed as a waiver of any right or benefit to which employees are entitled by law.
30
11001

<a id="page-32"></a>
## Page 32  ·  _OCR-reconstructed_

ARTICLE XXIX - SAVING CLAUSE
If any provision of this Agreement is found to be invalid such invalidity shall not impair the validity
and enforceability of the remaining provisions of this Agreement.
ARTICLE XXX - FINANCIAL EMERGENCY ACT
The provisions of this Agreement are subject to applicable provisions of law, including the New
York State Financial Emergency Act for the City of New York, as amended.
31
11001

<a id="page-33"></a>
## Page 33  ·  _OCR-reconstructed_

Sept. 3, 2010
IN WITNESS WHEREOF, the parties have executed this agreement on the day and year first
above written.
CITY OF NEW YORK
PATROLMEN'S BENEVOLENT
ASSOCIATION OF THE CITY
OF NEW YORK, INC.
BY:
BY:
JAMES F. HANLEY
Commissioner of
Labor Relations
at.
PATRICKO
President
APPROVED AS TO FORM:
BY:
ACTING CORPORATION COUNSEL
DATE SUBMITTED TO THE
FINANCIAL CONTROL BOARD:
UNIT: Police Officer
TERM: August 1, 2006 to July 31, 2010
OFFICIAL
OFFICE OF LA: RELATIONS
REGICTRATION
CONTRACT
NO:
11001
DATE:
SEP 0 3 2010
32

<a id="page-34"></a>
## Page 34  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
Mr. Patrick Lynch
President
Patrolmen's Benevolent Association
40 Fulton Street
New York, New York 10038-1850
Re: PBA Agreement covering the period from August 1, 2006 through July 31, 2010
Dear Mr. Lynch:
This is to confirm our mutual understanding and agreement regarding the method of calculating
the 20 and 25 years of service for the "pensionability" of longevity adjustments pursuant to
Article VIII, Section 1(g) of the Agreement. The following categories of service shall be
considered police service for purposes of computing the 20 or the 25 year pensionability of
longevity differential payments:
- laid-off police time which has been purchased for pension credit
prior City uniformed service
- prior State service credited under the pension law as uniformed service.
The following category of service shall be considered police service for purposes of computing
the 25 year pensionability of longevity differential payment:
- prior City service, including trainee time
If the above conforms to your understanding, please execute the signature line below.
ery truly yours,
toms
James F. Hanley
Patrick J. Lynch
33
11001

<a id="page-35"></a>
## Page 35  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OfFIcE OF LaBOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
Mr. Patrick Lynch
President
Patrolmen's Benevolent Association
40 Fulton Street
New York, New York 10038-1850
Re: PBA Agreement covering the period from August 1, 2006 through July 31, 2010
Dear Mr. Lynch:
The City and the PBA recognize that, pursuant to Administrative Code Section 12-127, the City
is obligated to pay for the cost of line of duty injury prescription drugs for PBA members. The
parties further recognize that a significant number of PBA members have utilized the PBA
Health and Welfare fund to pay for these prescription drugs without reimbursement by the City.
The PBA agrees to waive any and all claims retroactively and prospectively against the City for
the reimbursement of the cost of line of duty injury prescription drugs.
Nothing contained in this letter is intended to modify or amend the arbitrator's award in OCB
docket no. A-12057-06.
If the above conforms to your understanding, please execute the signature line below.
Very truly yours,
Jame I Harley
James F. Hanley
AGREEAND ACCERTED ON REHALF OF THE PBA
Patrick J. Lynch
President
34
11001

<a id="page-36"></a>
## Page 36  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
Mr. Patrick Lynch
President
Patrolmen's Benevolent Association
40 Fulton Street
New York, New York 10038-1850
Re: PBA Agreement covering the period from August 1, 2006 through July 31, 2010
Dear Mr. Lynch:
This is to confirm our mutual understanding and agreement regarding the above Agreement.
Effective the first day of the month following ratification of this Agreement a pilot program
concerning Patrol Guide Procedures 205-01 and 205-45 will be established.
This pilot program will be implemented subject to the following terms:
The pilot program will provide that eligible employees, who request sick leave for an injury
or illness, shall no longer be subject to home visitation and confinement, outside the hours
of the employce's regularly scheduled tour of duty, except where the convalescence for the
injury or illness requires home confinement in the opinion of the Deparment's Medical
Division, after consultution with the employce's personal physician.
The following employees are not cligible to participate in the program:
Any Employee who is designated as 'chronic sick'
2)
3)
Any Employee who is on modified assignment,
Any Employec who is on dismissal probation,
Any Employee who is on suspension.
c.
'The initial phase of the pilot progrun will run for a periud of 15 months. Provided
however, that in the event the initial phase of the pilot program is deemed to be successlul.
whereby the annualized average sick leave usuge for the entire PRA hargaining unit in the
15 month period is less than the designated absence rate plus 10%, the pilot program will
automatically be extended until the end of the this contract ter. If he second phase of the
pilot program is successful, whereby the annualized average sick leave usage for the entire
PBA bargaining unit in the second phasc of the pilot program is less than the designated
absence rate, plus 10% the parnes will meet to discuss implementing the pilot progra on a
permanent basis.
35
İ100

<a id="page-37"></a>
## Page 37  ·  _OCR-reconstructed_

1) For purposes of this agreement the designated absence rate' is the average lost days.
including both line of duty and non-line of duty sick leave, per member of service in the
PBA bargaining unit for Fiscal Year 2007-2008, which equals 11.56 days per year.
2) The Department. on the first day of cach month, will review police officer availability
for the preceding 365 days. In the event that police officer average sick leave for the
entire PBA bargaining unit exceeds the designated absence rate for the preceding 365
day period by more than 10%, the previous Patrol Guide home visitaion and
continement policies will he placed into effect the following day. Such procedures will
remain in effect for the remainder of the month. Provided however, the Police
Commissioner in his own discretion may permit the new procedures to remain in effect.
3) The following month another review of sick leave asage for the preceding 365 days will
occur. When a monthly review results in a return to a level at or below the "designated
absence rate" plus 10% the Department will resume the new visitation and confinement
procedures the following day (the second dy of the month).
If the above accords with your understanding, please execute the signature line below.
Very truly yours,
Jame I Manley
James F. Hanley
AGREED AND ACCEPTED ON BEHALF OF THE PBA
BY:
Patrick J. L
УПСП
11001
36

<a id="page-38"></a>
## Page 38  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, N.Y. 10006
JAMES F. HANLEY
Commissioner
CAROLINE I. SULLIVAN
First Dépury Commissioner
Mr. Louis Matarazzo, President
Patrolmen's Benevolent Association
40 Fulton Street
New York, NY 10038
Re: P.B.A. AGREEMENT FOR THẸ PERIOD
APRIL 1, 1995 TO JULY 31, 2000
Dear Mr. Matarazzo:
This is to confirm that during negotiations for the successor agreement to this 1995-2000
agreement the parties shall negotiate the issue of increasing the City's contribution to the PBA
Health and Welfare Fund as the first issue to be addressed. The issues to be negotiated shall
include the intent of the parties to equalize the City's total contribution to the PBA Health and
Welfare Fund with the total contributions made by the City to other health and welfare funds on
behalf of other employees and that the PBA shall be responsible for the cost of such increased
comtributions.
If the above conforms to your understanding, please execute the signature line below.
Yery truly yours,
Darli
(Sames F. Hanley
AGREED AND ACCEPTED ON BEHALF OF PBA
Toni mates
Louis Matarazzo
07003
11001

<a id="page-39"></a>
## Page 39  ·  _OCR-reconstructed_

THE POLICE COMMISSIONER
CITY OF NEW YORK
YORK
Mr. Patrick Lynch, President
Patrolmen's Benevolent Association
40 Fulton Street
New York, NY 10038-1850
Re:
P.B.A. AGREEMENT FOR THE PERIOD
AUGUST 1, 2006 TO JULY 31, 2010
Dear Mr. Lynch:
Please be advised that in fiscal years 2007, 2008, 2009, 2010 and 2011, the
Police Department will purchase radio motor patrol and radio emergency cars with air
conditioning.
uncerely,
Retur
Raymond W. Kelly
Police Commissioner
1 Police Plaza, New York, NY 10038 • 646-610-5410 • Fax: 646-610-5865
Website: http://nyc.gov/nypa
70OIE

---
_End of contract. Source PDF: <https://www.nyc.gov/assets/olr/downloads/pdf/collectivebargaining/cbu79-police-patrolmens-benevolent-association-080106-to-073110.pdf>_
