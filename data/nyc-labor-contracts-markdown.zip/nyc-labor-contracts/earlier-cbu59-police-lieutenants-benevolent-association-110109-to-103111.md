---
contract_id: earlier-cbu59-police-lieutenants-benevolent-association-110109-to-103111
label: "Lieutenants' Benevolent Association 2009-2011 Agreement (executed contract)"
expanded_label: "Lieutenants' Benevolent Association 2009-2011 Agreement (executed contract)"
term_start: 2009
term_end: 2011
source_pdf: "https://www.nyc.gov/assets/olr/downloads/pdf/collectivebargaining/cbu59-police-lieutenants-benevolent-association-110109-to-103111.pdf"
era: "earlier"  # older agreement, may be superseded in part by later documents
later_documents: ["lba-10-5-2023-unit-bargaining-agreement"]
pages: 46
ocr_pages: 46
pages_with_tables: 0
clauses: 93
---

# Lieutenants' Benevolent Association 2009-2011 Agreement (executed contract)

> **Earlier agreement, may be superseded.** Later documents keep parts of it in force and change others; where they conflict, the later document governs. Check them before relying on any clause: lba-10-5-2023-unit-bargaining-agreement.

**Term:** 2009–2011  
**Source PDF:** [https://www.nyc.gov/assets/olr/downloads/pdf/collectivebargaining/cbu59-police-lieutenants-benevolent-association-110109-to-103111.pdf](https://www.nyc.gov/assets/olr/downloads/pdf/collectivebargaining/cbu59-police-lieutenants-benevolent-association-110109-to-103111.pdf)  
**Pages:** 46 (46 OCR-reconstructed)  
**Clauses extracted:** 93

> This Markdown export is derived from the source PDF via `pdfplumber` text extraction with `ocrmac` (macOS Vision) OCR fallback for image-only pages. Tables were detected and rendered as pipe-delimited Markdown so column boundaries survive. Pages flagged `OCR` were reconstructed from page images and may contain minor character recognition errors — verify quotations against the source PDF before publishing.

---

## Contents

- [Letter: TERM](#page-1)
- [Cover memo from the Office of Labor Relations](#page-1)
- [Untitled section](#page-1)
- [FEB 0 2 2009](#page-1)
- [Article II — UNION SECURITY-DUES CHECKOFF](#page-2)
- [Article V — COMPUTATION OF BENEFITS](#page-2)
- [Article X — LEAVES...](#page-2)
- [Article XXII — LINE-OF-DUTY DEATH BENEFIT](#page-2)
- [Article XXXII — TERM](#page-2)
- [Article I — UNION RECOGNITION AND UNIT DESIGNATION](#page-3)
- [Article II — UNION SECURITY-DUES CHECKOFF](#page-4)
- [Article III — HOURS AND OVERTIME](#page-4)
- [Article IV — RECALL AFTER TOUR](#page-6)
- [Article V — COMPUTATION OF BENEFITS](#page-7)
- [Article VI — SALARIES](#page-7)
- [Section 5 — Salary Itemization](#page-9)
- [Article VII — UNIFORM ALLOWANCE](#page-9)
- [Article VIII — LONGEVITY ADJUSTMENTS](#page-9)
- [Article IX — PAYMENT FOR HOLIDAY WORK](#page-11)
- [Section 1 — Sick Leave](#page-11)
- [Section 2 — Death-in-Family Leave](#page-11)
- [Section 3 — Military Leave](#page-11)
- [Section 4 — Special Excusals](#page-11)
- [Section 5 — Leave to Attend Hearings](#page-12)
- [Article XI — VACATIONS](#page-12)
- [Section 3 — Accrual of Vacation](#page-12)
- [Article XII — HEALTH AND WELFARE FUND](#page-13)
- [Article XIII — HEALTH AND HOSPITALIZATION BENEFITS](#page-14)
- [Section 5 — Health Care Flexible Spending Account.](#page-16)
- [Section 125 — of the IRS Code. Those employees eligible for New York City health plan](#page-16)
- [Article XIV — -](#page-16)
- [Article XIV — -](#page-17)
- [Article XV — SENIORITY](#page-17)
- [Section 1 — Safety Helmets](#page-17)
- [Section 2 — Parking Facilities](#page-17)
- [Section 3 — Maintenance of Facilities](#page-18)
- [Section 4 — Private Hospital Accommodations for Line-of-Duty Injuries](#page-18)
- [Section 5 — Information Exchange](#page-18)
- [Section 6 — Meal Areas](#page-19)
- [Section 7 — Personal Folder](#page-19)
- [Section 8 — Disciplinary Records](#page-19)
- [Section 9 — Disciplinary Procedures](#page-19)
- [Section 10 — Fixed Post Duty](#page-20)
- [Section 11 — Meal Scheduling](#page-20)
- [Section 12 — Lump Sum Payments](#page-20)
- [Section 13 — Interest Payments](#page-20)
- [Section 14 — Public Transportation](#page-21)
- [Section 15 — Polygraphs](#page-21)
- [Section 16 — Probationary Period](#page-21)
- [Section 17 — Performance Compensation](#page-21)
- [Article XVII — UNION ACTIVITY](#page-22)
- [Article XVIII — NO DISCRIMINATION](#page-22)
- [Article XIX — NIGHT SHIFT DIFFERENTIAL](#page-22)
- [Article XX — OVERTIME TRAVEL GUARANTEE](#page-23)
- [Section 1 — Definitions](#page-24)
- [STEP L](#page-25)
- [Article XXII — LINE-OF-DUTY DEATH BENEFIT](#page-28)
- [COMPENSATORY TIME](#page-28)
- [Article XXIV — OPTIONAL WORK DURING VACATIONS](#page-29)
- [Article XXV — NO STRIKES](#page-29)
- [DESIGNATED](#page-30)
- [Article XXVII — BULLETIN BOARDS](#page-30)
- [Article XXVIII — NO WAIVER](#page-30)
- [Article XXIX — SAVINGS CLAUSE](#page-30)
- [Article XXX — LABOR MANAGEMENT COMMITTEE](#page-30)
- [Article XXXI — FINANCIAL EMERGENCY ACT](#page-31)
- [Article XXXII — TERM](#page-31)
- [IN WITNESS WHEREOF](#page-32)
- [NEW YORK](#page-32)
- [NEW YORK (continued)](#page-32)
- [REGISTRATION](#page-32)
- [DATE SUBMITTED TO THE](#page-32)
- [FEB 0 2 2009](#page-32)
- [Letter: LBA AGREEMENT FOR THE PERIOD](#page-33)
- [FEB 0 2 2009 (continued)](#page-34)
- [Letterhead](#page-34)
- [LBA AGREEMENT FOR THE PERIOD](#page-34)
- [Letter: LBA Agreement for the period](#page-35)
- [Letter: LBA Agreement for the period November 1, 2009 to October 31, 2011](#page-36)
- [Letter: LBA Agreement for the period November 1, 2009 to October 31, 2011](#page-37)
- [Letter: LBA Agreement for the period](#page-39)
- [Signatures](#page-39)
- [Letter: LBA Agreement for the period](#page-40)
- [Letter: LBA Agreement for the period](#page-41)
- [Signatures](#page-41)
- [Letter: LBA Agreement for the period](#page-42)
- [Signatures](#page-42)
- [Letter: LBA Agreement for the period](#page-43)
- [Signatures](#page-43)
- [Letter: LBA Agreement for the period](#page-44)
- [Signatures](#page-44)
- [Letter: LBA Agreement for the period](#page-45)
- [Signatures](#page-46)

---

<a id="page-1"></a>
## Page 1  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner.
MARGARET M. CONNOR
First Deputy Commissioner
TO:
FROM:
SUBJECT:
TERM:
HEADS OF CONCERNED CITY DEPARTMENTS AND AGENCIES
JAMES F. HANLEY, COMMISSIONER
Homer
7 Hanter
EXECUTED CONTRACT: LIEUTENANTS
NOVEMBER 1, 2009 TO OCTOBER 31, 2011
Attached for your information and guidance is a copy of the executed contract entered
into by the Commissioner of Labor Relations on behalf of the City of New York and the
Lieutenants Benevolent Association on behalf of the incumbents of positions listed in Article I of
said contract.
The contract incorporates terms of an agreement reached through collective bargaining
negotiations and related procedures.
DATED: FEB 0 2 2009
OFFICE OF LABOR RELATIONS
REGISTRATION
OFFICIAL
CONTRACT
NO:
09011
DATE:
FEB 0 2 2009

<a id="page-2"></a>
## Page 2  ·  _OCR-reconstructed_

Lieutenants' Benevolent Association
2009-2011 Agreement
TABLE OF CONTENTS
ARTICLE I - UNION RECOGNITION AND UNIT DESIGNATION
ARTICLE II - UNION SECURITY-DUES CHECKOFF
2
3
ARTICLE III - HOURS AND OVERTIME
ARTICLE IV - RECALL AFTER TOUR..
ARTICLE V - COMPUTATION OF BENEFITS
5
6
ARTICLE VI - SALARIES..
ARTICLE VII - UNIFORM ALLOWANCE..
ARTICLE VIII - LONGEVITY ADJUSTMENTS.
ARTICLE IX - PAYMENT FOR HOLIDAY WORK
ARTICLE X - LEAVES...
- 8
8
10
. 10
ARTICLE XI - VACATIONS..
ARTICLE XII - HEALTH AND WELFARE FUND
ARTICLE XIII - HEALTH AND HOSPITALIZATION BENEFITS
ARTICLE XIV - ANNUITY FUND..
ARTICLE XV - SENIORITY
ARTICLE XVI - GENERAL.
ARTICLE XVII - UNION ACTIVITY ...
ARTICLE XVIII - NO DISCRIMINATION..
ARTICLE XIX - NIGHT SHIFT DIFFERENTIAL
ARTICLE XX - OVERTIME TRAVEL GUARANTEE
ARTICLE XXI - GRIEVANCE AND ARBITRATION PROCEDURE.
ARTICLE XXII - LINE-OF-DUTY DEATH BENEFIT
ARTICLE XXIII - DEATH BENEFIT-UNUSED LEAVE AND COMPENSATORY TIME....28
ARTICLE XXIV - OPTIONAL WORK DURING VACATIONS..
ARTICLE XXV - NO STRIKES ..
ARTICLE XXVI - EMPLOYEES SPECIALLY ASSIGNED OR DESIGNATED
ARTICLE XXVII - BULLETIN BOARDS.
ARTICLE XXVIII - NO WAIVER...
ARTICLE XXIX - SAVINGS CLAUSE
ARTICLE XXX - LABOR MANAGEMENT COMMITTEE
ARTICLE XXXI - FINANCIAL EMERGENCY ACT
ARTICLE XXXII - TERM
12
13
15
16
16
.21
.. 21
. 21
. 22
.. 23
.27
28
... 28
.29
. 29
29
..29
..29
.30
.. 30
2009-2011 LBA
09011

<a id="page-3"></a>
## Page 3  ·  _OCR-reconstructed_

Lieutenants' Benevolent Association
2009-2011 Agreement
Agreement made this day of fel, 2008 by and between the City of New York (hereinafter
called "the City" or "the Employer"), acting by the Commissioner of Labor Relations, and the
Lieutenants' Benevolent Association of the City of New York (hereinafter called "the Union" or
the "LBA"), for the period from November 1, 2009 to October 31, 2011.
WITNESSETH:
WHEREAS, the Lieutenants employed by the City have duly designated the Union as their
exclusive bargaining representative for the purpose of collective bargaining with the City with
respect to wages, hours and conditions of employment; and
WHEREAS, the Union and the City desire to cooperate in establishing conditions which will
tend to secure standards and conditions of employment consistent with the dignity of Lieutenants,
and to provide methods for fair and peaceful adjustment of disputes that may arise between the
Union and the City; and
WHEREAS, as a result of collective bargaining the parties have reached an Agreement which
they desire to reduce to writing;
NOW, THEREFORE, it is mutually agreed as follows:
ARTICLE I - UNION RECOGNITION AND UNIT DESIGNATION
Section 1.
The City recognizes the Union as the sole and exclusive collective bargaining representative for the
unit consisting of the employees of the New York City Police Department in the title of Lieutenant.
Section 2.
Except as otherwise provided herein, for purposes of this Agreement, the terms "employee" or
"employees" and "Lieutenant' or "Lieutenants" shall be interchangeable and shall relate solely to
employees in the unit described in Section 1 of this Article.
2009-2011 LBA

<a id="page-4"></a>
## Page 4  ·  _OCR-reconstructed_

ARTICLE II - UNION SECURITY-DUES CHECKOFF
Section 1.
All employees covered by this agreement shall be free to become and remain members of the Union
in good standing.
Section 2.
The Union shall have the exclusive right to the checkoff and transmittal of dues in behalf of each
employee in the unit in accord with the Mayor's Executive Order No. 98, dated May 15, 1969,
entitled "Regulations Regulating the Checkoff of Union Dues" and in accord with the Mayor's
Executive Order No. 107, dated December 29, 1986, entitledồiRegulations Governing Procedures for
Orderly Payroll Checkoff of Union Dues and Agency Shop Fees" and any executive orders which
amend or supersede said Executive Orders.
Section 3.
An employee may consent in writing to the authorization of the deduction of dues from the
employee's wages and to the designation of the Union as the recipient thereof. Such consent, if
given, shall be in a proper form, in accord with Section 2 of this Article II, which bears the signature
of the employee.
Section 4.
The parties agree to an agency shop to the extent permitted by applicable law, as described in a
supplemental agreement hereby incorporated by reference.
ARTICLE III - HOURS AND OVERTIME
Section la.
Except as otherwise provided herein, all ordered and/or authorized overtime in excess of 40 hours in
any week or in excess of the hours required of an employee by reason of the employee's regular duty
chart if a week's measurement is not appropriate, whether of an emergency nature or of a
non-emergency nature, shall be compensated for either by cash payment or compensatory time off, at
the rate of time and one-half, at the sole option of the employee. Such cash payments or
compensatory time off shall be computed on the basis of completed fifteen (15) minute segments.
2009-2011 LBA
09011

<a id="page-5"></a>
## Page 5  ·  _OCR-reconstructed_

Section 1b.
In order to preserve the intent and spirit of this Section on overtime compensation, there shall be no
rescheduling of days off and/or tours of duty. This restriction shall apply both to the retrospective
crediting of time off against hours already worked and to the anticipatory re-assignment of personnel
to different days off and/or tours of duty. Notwithstanding anything to the contrary contained herein,
the Department shall not have the right to reschedule employees' tours of duty, except that the
Department shall have the right to reschedule employees' tours of duty on ten (10) occasions without
payment of pre-tour or post-tour overtime provided that the Department gives at least 24 hours notice
to the employees whose tours are to be rescheduled, and that on the following occasions the
Department may reschedule employees' tours of duty by not more than three hours before or after
normal starting time for such tours, without payment of pre-tour or post-tour overtime provided that
the Department gives at least seven days' advance notice to the employees whose tours are to be so
rescheduled: New Year's Eve, St. Patrick's Day, Thanksgiving Day, Puerto Rican Day, West Indies
Day and Christopher Street Liberation Day. This Section 1b shall not apply to employees assigned to
onicky. This s
the Detective Bureau and/or "Designated as Commander of Detective Squad" and/or "Designated on
Special Assignmentại
Effective June 16, 2006, the Department shall have the right to reschedule employeeẾours of duty
on fifteen (15) occasions without payment of pre-tour or post-tour overtime provided that the
Department gives at least 24 hours notice to the employees whose tours are to be rescheduled. The
Department may also reschedule employees' tours of duty, without payment of pre-tour or post-tour
overtime, for New Year's Eve, St. Patrick's Day, Thanksgiving Day, Puerto Rican Day, West Indies
Day and Christopher Street Liberation Day, provided that the Department gives notice before
12:00am of the day(s) in question. The three (3) hour rescheduling limitation for the above named
dates is also eliminated.
Effective July 7, 2008, the Department shall have the right to reschedule employeesẾours of duty on
twenty (20) occasions without payment of pre-tour or post-tour overtime provided that the
Department gives at least 24 hours notice to the employees whose tours are to be rescheduled. The
Department may also reschedule employees' tours of duty, without payment of pre-tour or post-tour
overtime, for New Year's Eve, St. Patrick's Day, Thanksgiving Day, Puerto Rican Day, West Indies
Day and Christopher Street Liberation Day, provided that the Department gives notice before
12:00am of the day(s) in question. The three (3) hour rescheduling limitation for the above named
dates is also eliminated.
Section 2.
Notwithstanding anything to the contrary in this Agreement, employees assigned to the Detective
Bureau and/or "Designated as Commander of Detective Squad" and/or "Designated on Special
Assignmen_ằ_shall receive overtime compensation in the same manner and subject to the same
limitations as the members of the Force detailed as First, Second or Third Grade Detectives.
2009-2011 LBA

<a id="page-6"></a>
## Page 6  ·  _OCR-reconstructed_

Section 3.
Overtime shall be computed on a monthly basis and shall be paid no later than six (6) weeks after
submission of the monthly report.
ARTICLE IV - RECALL AFTER TOUR
Section 1.
Any employee who is recalled to duty after having completed the employee's regular tour of duty but
four (4) hours or more before the commencement of the employee's next regular tour and is released
without having been assigned to duty prior to the commencement of said next regular tour shall
receive a minimum of four hours' pay pursuant to the regular overtime provisions of this Agreement,
that is, in cash or compensatory time off at the sole option of the employee at the rate of time and
one-half (i.e., the equivalent of six hours compensation at the employee's straight time rate).
Section 2.
Any employee who is recalled to duty after having completed the employee's regular tour of duty but
six (6) hours or more before the commencement of the employee's next regular tour and who is
assigned to duty and then released from duty prior to commencement of said next regular tour shall
receive a minimum of six hours' pay pursuant to the regular overtime provisions of this Agreement,
that is, in cash or compensatory time off, at the employee's sole option, at the rate of time and
one-half (i.e., the equivalent of nine hours' compensation at the employee's straight time rate).
Section 3.
In the event the actual time spent on recall defined in Sections 1 and 2 of this Article extends beyond
the minimum periods provided therein, the employee shall receive pay pursuant to the regular
overtime provisions of this Agreement for the full period of time actually spent on such recall.
Section 4.
Notwithstanding anything to the contrary provided in Sections 1 through 3 of this Article, any
employee who is recalled to duty after having completed the employee's regular tour of duty but
before the commencement of the employee's next regular tour and who is assigned to duty or held
without assignment for a period which extends into the commencement of that next regular tour shall
receive pay pursuant to the regular overtime provisions of this Agreement only for the actual time so
assigned or held.
2009-2011 LBA
5

<a id="page-7"></a>
## Page 7  ·  _OCR-reconstructed_

Section 5a.
Notwithstanding anything to the contrary in Sections 1 through 4 of this Article, any employee who
is recalled to duty after having completed the employee's regular tour of duty but less than four hours
before the commencement of the employee's next regular tour and who is released without having
been assigned to duty prior to the commencement of that next regular tour shall receive pay in cash
or compensatory time off at the employee's sole option, at the rate of time and one-half, for the
actual time between the beginning of such recall and the commencement of that next regular tour.
Section 5b.
Notwithstanding anything to the contrary in Sections 1 through 4 of this Article, any employee who
is recalled to duty after having completed the employee's regular tour of duty but less than six hours
before the commencement of the employee's next regular tour and who is assigned to duty and then
released from duty prior to the commencement of that next regular tour shall receive pay in cash or
compensatory time off at the employee's sole option, at the rate of time and one-half, for the actual
time between the beginning of such recall and the commencement of that next regular tour.
ARTICLE V - COMPUTATION OF BENEFITS
Since the basic forty-hour week has not been changed by this Agreement, any modifications of a
standard chart and use of other tours shall not affect current standard practice for the computation of
compensation for holidays, vacation days, personal leave days, annuity fund contributions and other
relevant benefits, which shall remain on the basis of an eight-hour workday calculation.
ARTICLE VI - SALARIES
Section la.
The following base annual salary and increment rates shall prevail for employees during the term of
this Agreement:
Class of Positions and Steps
(i) Lieutenant
1S Step
2nd Step
3id Step
4th Step
Effective
11/1/2009
$98,164
$98,550
$99,000
$108,244
Effective
11/1/2010
$102,091
$102,492
$102,96ął
$112,574
2009-2011 LBA

<a id="page-8"></a>
## Page 8  ·  _OCR-reconstructed_

(ii) Lieutenant
Designated on Special Assignment or as Commander Detective Squad
15" Step
2nd Step
3rd Step
4th Step
Effective
11/1/2009
$109,187
$110,317
$111,747
$119,073
Effective
11/1/2010
$113,554
$114,730
$116,217
$123,83ťîšŚ
(iii)
The salary increases and base annual salary and increment rates for Lieutenant detailed as
Director of Legal Bureau shall be fixed in accordance with the formula agreed to and used by the
parties in the Agreement for the period January 1, 1971 to June 30, 1973.
Section 1b.
An employee shall advance one increment step annually on the anniversary date of the employee's
appointment to the class of positions occupied.
Section 2.
A laid off employee who is returned to service in the employee's former title or in a comparable title
from a preferred list, shall receive the basic salary rate that would have been received by the
employee had the employee never been laid off, up to a maximum of two (2) years of general salary
increases.
Section 3.
a.
(i)
(ii)
b.
General Wage Increase.
Effective November 1, 2009 Employees shall receive a rate increase of 4%.
Effective November 1, 2010, Employees shall receive an additional rate increase of
4%.
The increases provided for in this Section 3a above shall be calculated as follows:
The increase in Section 3a(i) shall be based upon the base rates (which shall include
salary or incremental schedules) of the applicable titles in effect on October 31, 2009;
2009-2011 LBA

<a id="page-9"></a>
## Page 9  ·  _OCR-reconstructed_

and
(ii)
The rate increase in Section 3a (ii) shall be based upon the base rate (which shall
include salary or incremental schedules) of the applicable titles in effect on October
31, 2010.
The general increase provided in this Section 3 shall be applied to the base rates and salary
grades fixed for the applicable titles.
Section 4.
Paychecks shall be delivered to commands by 3:00 p.m. on the Thursday preceding payday for
distribution after 3:00 p.m. on said Thursday.
Section 5. - Salary Itemization
The Department shall make available in convenient places in each precinct the appropriate payroll
work sheets for the purpose of enabling each employee to verify the salary components of the
employee's paycheck. The parties will review further the feasibility of otherwise advising each
employee of all payroll components along with the employee's paycheck.
ARTICLE VII - UNIFORM ALLOWANCE
In Fiscal Years 2010 and 2011 the City shall pay to each employee a uniform allowance of $1,100 in
accord with the existing standard procedures.
ARTICLE VIII - LONGEVITY ADJUSTMENTS
Section 1.
a.
(i)
(¡i)
Effective November 1, 2009 longevity adjustments shall continue to be paid as follows:
Upon the completion of five years of service, employees shall receive a longevity
adjustment of $5,745.
Upon completion of ten years of service, employees shall receive a longevity
adjustment of an additional $1,000.
2009-2011 LBA

<a id="page-10"></a>
## Page 10  ·  _OCR-reconstructed_

b.
(iii)
Upon completion of fifteen years of service, employees shall receive a longevity
adjustment of an additional $1,000.
(iv)
Upon completion of twenty years of service, employees shall receive a longevity
adjustment of an additional $1,000.
Effective October 31, 2011, longevity adjustments shall be paid as follows:
(i)
Upon the completion of five years of service, employees shall receive a longevity
adjustment of $5,745.
(ii)
Upon completion of ten years of service, employees shall receive a longevity
adjustment of an additional $1,000.
(iii)
Upon completion of fifteen years of service, employees shall receive a longevity
adjustment of an additional $1,500.
(iv)
Upon completion of twenty years of service, employees shall receive a longevity
adjustment of an additional $1,000.
Section 2.
a.
b.
c.
The adjustment after the 5th and 10th years shall not be computed as salary for pension
purposes until after completing 20 years of service.
The adjustment after the 15th and 20th years shall not be computed as salary for pension
purposes until after completion of 25 years of service.
In the event this provision is declared invalid under the law, the parties shall reopen
negotiations to resolve the issue of the increased cost of changing the effective date of the
pensionability of the above adjustments. Such negotiations will be commenced forthwith. If
no agreement is reached, an impasse may be declared and subsequent mediation and the
impasse proceeding, if any, shall in all respects be conducted on an
expedited basis.
The calculation of night shift differential payments shall be based upon the same factors,
amounts and methodology as previously utilized.
ITHP and pension benefit calculations shall only include the amount of the longevity
payment that is pensionable.
2009-2011 LBA
9

<a id="page-11"></a>
## Page 11  ·  _OCR-reconstructed_

ARTICLE IX - PAYMENT FOR HOLIDAY WORK
Each employee shall receive eleven (11) paid holidays annually, payments for which shall be made in
accord with existing procedures.
ARTICLE X - LEAVES
Section 1. - Sick Leave
a.
()
Each employee shall be entitled to leave with pay for the full period of any incapacity
due to illness, injury or mental or physical defect which is service-connected pursuant
to Section 14-122.1 of the Administrative Code.
(ii)
Each employee shall be entitled to leave with pay for the full period of any incapacity
due to illness, injury or mental or physical defect, whether or not service-connected.
b.
The Chief of Personnel shall consult with representatives of the LBA regarding the
enforcement of the sick leave program in order to insure that undue restrictions will not be placed
upon Lieutenants. Departmental orders in connection therewith shall be issued after consultation
with the LBA.
Section 2 - Death-in-Family Leave
In the event of a death in an employee's immediate family and upon application to and approval of
the employee's commanding officer or supervisory head, the employee shall receive leave with pay
not exceeding four consecutive regular tours of duty. For the purposes of this section, the phrase,
*immediate family, shall include any of the following: (a) a spouse, (b) a natural, foster or
step-parent, child, brother or sister, (c) a father-in-law or mother-in-law, or (d) any relative residing
in the employee's household. The commanding officer or supervisory head granting such leave shall
verify the death and relationship of the deceased. If the deceased was in the military service of the
United States at the time of the death, the employee requesting leave shall produce the official notice
of death.
Section 3. - Military Leave
Military leave not exceeding a total of thirty (30) days in any one calendar year and not exceeding
thirty (30) days in any one continuous period of such absence shall be granted with pay to any
employee requiring such leave to satisfy military obligations.
Section 4. - Special Excusals
Excused time accorded to other personnel employed by the City under circumstances such as
excusals for the Dr. Martin Luther King, Jr. and the Senator Robert F. Kennedy funerals and the
2009-2011 LBA
10

<a id="page-12"></a>
## Page 12  ·  _OCR-reconstructed_

Moon Landing Observation Day shall be granted equally to employees covered by this Agreement.
All compensating days off shall be subject to exigencies of the Department.
Section 5. - Leave to Attend Hearings
Individual employee grievants shall be granted leave with pay for such time as is necessary to testify
at arbitration hearings.
Leave with pay shall be granted to three (3) employees who are named grievants in a group
arbitration proceeding, for such time as is necessary for them to testify at their group arbitration
hearings.
Leave with pay for such time as is necessary to testify at their hearings shall be granted to employees
who, after final adjudication of proceedings under Section 210, paragraph 2h of the Civil Service
Law are determined not to have been in violation of Section 210.
ARTICLE XI - VACATIONS
Section l.
The Department shall continue to provide authorized annual vacations of twenty-seven work days.
Section 2.
Employees may select individual vacation days at the time vacations are picked, provided that the
maximum number of employees allowed to take such individual vacation days at any time shall be
2% of the Unit Rank Complement, and provided further that no employee may choose more than one
of the following holidays as an individual vacation day: Independence Day, Labor Day,
Thanksgiving Day, Christmas Day and New Year's Day. Any employee who fails to select such
individual vacation days at the time the employee makes the regular vacation pick may select such
individual vacation days at a later time subject to the exigencies of the Department. Such individual
vacation days shall be treated as regular vacation picks.
Section 3. - Accrual of Vacation
If the Police Department calls upon an employee in writing to forego the employee's vacation or any
part thereof that portion up to a maximum of three weeks of vacation shall be carried over until such
time as it can be liquidated in the following calendar year subject to the following conditions:
(1)
the selection of such vacation days shall be in the discretion of and subject to the
exigencies of the Department; and
2009-2011 LBA
11

<a id="page-13"></a>
## Page 13  ·  _OCR-reconstructed_

(2)
(3)
the selection of such days in the following calendar year shall be made after the
regular vacation picks; and
the utilization of this vacation time shall be restricted to the months of January
through May and September through November.
It is the intention of the Police Department to allow an employee to request permission to accrue
vacation consistent with this provision and to grant such requests which are reasonable.
ARTICLE XII - HEALTH AND WELFARE FUND
Section 1.
b.
C.
d.
Effective November 1, 2009, the City shall continue to contribute the pro-rata annual amount
of $1,500 for each employee for remittance to the Health and Welfare Fund of the
Lieutenants' Benevolent Association of the City of New York (Welfare Fund) pursuant to
the terms of a supplemental agreement to be reached by the parties subject to the approval of
the Corporation Counsel.
Pursuant to its commitment, the LBA will continue to provide benefits to employees
domestic partners.
To the extent permitted by law, part of the amounts so contributed may be applied to
maintain an appropriate legal services plan, pursuant to the terms of a supplemental
agreement between the parties as approved by the Corporation Counsel.
Effective June 16, 2003, employees who have been separated from service subsequent to
December 31, 1970, and who were covered by the Health and Welfare Fund of the
Lieutenants' Benevolent Association at the time of such separation pursuant to a
supplementary agreement between the City and the LBA shall continue to be so covered,
subject to the provisions of Sections 1 a and b hereof, on the same contributory basis as
incumbent employees. Contributions shall be made only for such time as said individuals
remain primary beneficiaries of the New York City Health Insurance Program and are
entitled to benefits paid for by the City through such Program.
e.
Civil Legal Representation Fund
Effective November 1, 2009, the City shall continue to contribute $75 per annum for each
active Employee to the Welfare Fund to the civil legal representation fund pursuant to the
terms of a supplemental agreement between the City and Union as approved by the
Corporation Counsel. While these funds shall be administered by the applicable Welfare
2009-2011 LBA
12
09011

<a id="page-14"></a>
## Page 14  ·  _OCR-reconstructed_

Fund, they are to be maintained in a separate account and shall not be commingled with the
other monies received by the Welfare Fund. Only the $75 provided above may be used for
civil legal representation. No additional monies from the Welfare Fund may be used for civil
legal representation.
f.
Such payments shall be made pro-rata by the City every twenty-eight (28) days.
Section 2.
Where an employee is suspended without pay for disciplinary reasons and is subsequently restored to
full pay status as of the date of the suspension, the employee shall receive full Health and Welfare
Fund coverage for the period of the suspension.
ARTICLE XIII - HEALTH AND HOSPITALIZATION BENEFITS
Section 1.
The City shall continue to provide a fully paid choice of health and hospitalization insurance plans
for each employee, not to exceed 100% of the full cost of HIP-HMO on a category basis. There will
be an annual reopening period during the term of this Agreement for active employees to exercise
their choice among medical plans.
Section 2.
Retirees shall have the option of changing their previous choice of Health Plans. This option:
(a)
shall be a one time choice;
(b)
shall be exercised only after one year of retirement; and
(c)
can be exercised at any time without regard to contract periods.
The effective date of change to a new plan shall be the first day of the month three months after the
month in which the application has been received by the New York City Health Insurance Program.
Effective with the reopener period for Health Insurance subsequent to January 1, 1980 and every two
years thereafter, retirees shall have the option of changing their previous choice of health plans. This
option shall be exercised in accordance with procedures established by the Employer. The Union will
assume the responsibility of informing retirees of this option.
2009-2011 LBA
13
09011

<a id="page-15"></a>
## Page 15  ·  _OCR-reconstructed_

Section 3.
a.
Effective July 1, 1983 and thereafter, the City's cost for each employee and for each retiree
under age 65 shall be equalized at the community rated basic HIP/HMO plan payment rate as
approved by the State Department of Insurance on a category basis of individual or family,
e.g. the GHI-CBP/Blue Cross payment for family coverage shall be equal to the HIP/HMO
payment for family coverage.
b.
c.
d.
e.
If a replacement plan is offered to employees and retirees under age 65 which exceeds the
cost of the HIP/HMO equalization provided in Section 3a, the City shall not bear the
additional costs.
The City shall continue to contribute on a City employee benefits program-wide basis the
additional annual amount of $30 million to maintain the health insurance stabilization
reserve fund which shall be used to continue equalization and protect the integrity of health
insurance benefits.
The health insurance stabilization reserve fund shall be used: to provide a sufficient reserve;
to maintain to the extent possible the current level of health insurance benefits provided
under the GHI-CBP/Blue Cross plan; and, if sufficient funds are available, to fund new
benefits.
The health insurance stabilization reserve fund shall be credited with the divisions or reduced
by the losses attributable to the GHI-CBP/Blue Cross plan.
Pursuant to paragraph 7 of MLC Health Benefits Agreement, notwithstanding the above, in
each of the fiscal years 2001 and 2002, the City shall not make the annual $35 million
contributions to the health insurance stabilization fund.
In the event that there is a Citywide or program-wide health insurance package which
exceeds the cost of the equalization and stabilization fund described above, the parties may
negotiate reconfiguration of this package which in no event will provide for costs in excess
of the total costs of this Agreement as set forth herein. However, it is understood that the
LBA will not be treated any better or any worse than any other Union Participating in the
Citywide or Program-wide Health Program with regard to increased health insurance costs.
Section 4.
Where an employee is suspended without pay prior to disciplinary trial for disciplinary reasons for
more than 30 days, the employee shall receive full health and hospitalization benefit coverage during
the period of the suspension following the first 30 days. Where an employee is subsequently restored
2009-2011 LBA
14
09

<a id="page-16"></a>
## Page 16  ·  _OCR-reconstructed_

to full pay status, as of the date of suspension, the employee shall be restored to full health and
hospitalization coverage for the first 30 days of the suspension.
Section 5. Health Care Flexible Spending Account.
b.
c.
A flexible health care spending account shall be established after July 1993 pursuant to
Section 125 of the IRS Code. Those employees eligible for New York City health plan
coverage as defined on page 32, section 4(B) of the 1992 New York City Health Summary
Program Description shall be eligible to participate in the account. Participating employees
shall contribute at least $260 per year up to a maximum of $5,000 per year. Said contribution
minimum and maximum levels may be modified by the MLC Health Advisory Committee
based on experience of the plan. Any unfunded balance may be deducted from final salary
payments due an employee.
Expenses of the account shall include but not be limited to deductibles, co-insurance, co-
payments, excess expenses beyond plan limits, physical exams and health related
transportation costs for vision, dental, medical and prescription drug plans where the
employee and dependents are covered. In no case will any of the above expenses include
those non-deductible expenses defined as non-deductible in IRS Publication 502.
An administrative fee of $1.00 per week for the first year shall be charged for participation in
the program. An employee's participation in the account is irrevocable during a plan year. At
the close of the plan year any excess balance in an employee's account will not be refunded.
ARTICLE XIV -
A. ANNUITY FUND
Section 1.
a.
Effective November 1, 2009, the City shall continue to contribute for each employee, on a
twenty eight (28) day cycle basis, a pro-rata daily contribution for each working day for
which such employee is paid by the City which amount shall not exceed: $1542.51 per
annum for each Lieutenant; $1,605.15 per annum for each Lieutenant designated on Special
Assignment or as Commander of Detective Squad; and, $1,766.97 for each Lieutenant
designated as Director of Legal Bureau.
Effective October 31, 2011, the City shall contribute to the annuity fund a one-time lump
sum payment in the amount of $892.00 on behalf of each active member.
2009-2011 LBA
15

<a id="page-17"></a>
## Page 17  ·  _OCR-reconstructed_

Section 2.
Where an employee is suspended without pay for disciplinary reasons and is subsequently restored to
full pay status as of the effective date of the suspension, the employee shall receive full Annuity
Fund coverage for the period of the suspension.
ARTICLE XIV -
B. DEFERRED COMPENSATION
Effective November 1, 2009, the City shall continue to contribute $300.00 per annum to the 401(a)
Savings Incentive Plan on behalf of each active Employee in the bargaining unit who a) is a member
of the 457 Plan and b) who invests a minimum of one percent (1%) of salary per annum.
Effective October 31, 2011, there shall be a $1,784 one-time lump sum payment per active eligible
employee into the 401(a) Savings Incentive Plan on behalf of each active Employee in the bargaining
unit who a) is a member of the 457 Plan and b) who invests a minimum of one percent (1%) of salary
per annum.
The Employee's 401(a) Plan account shall be invested in the same option(s) the Employee has
designated for his/her 457 Plan account. The Employee's beneficiary for the 401(a) Plan shall be the
same as the beneficiary designated by the Employee in the 457 Plan.
The parties will establish a labor-management committee to discuss implementation issues.
ARTICLE XV - SENIORITY
The Department recognizes the importance of seniority in filling vacancies within a command and
shall make every effort to adhere to this policy, providing the senior applicant has the ability and
qualifications to perform the work involved. While consultation on such matters is permissible, the
final decision of the Department shall not be subject to the grievance procedure.
ARTICLE XVI - GENERAL
Section 1. - Safety Helmets
The City agrees to furnish a safety helmet and equipment related thereto for each employee. Such
headgear shall conform to Police Department specifications in effect at the time of this Agreement.
Section 2. - Parking Facilities
It is the intent of the Department to make available without liability to the City, City-owned property
and on-street locations adjacent to, near or part of police stations or other command locations, as
2009-2011 LBA
16

<a id="page-18"></a>
## Page 18  ·  _OCR-reconstructed_

parking facilities for the personal cars of employees. A single designated representative of the
Department and a single designated representative of the Union will survey locations in the vicinity
of station houses to determine what space is available which could reasonably be used for police
parking and, where space exists, the Department and the Union will jointly request of the appropriate
City agency designation of such locations. This expressed intent of the Department does not imply
any obligation or commitment on the part of the City or the Department to make available any such
location or parking facilities. Where such property is provided and so designated for this purpose,
the City shall not be obligated to improve the same, nor to maintain it for parking. The City need not
continue to provide such property for parking when the City, in its discretion, decides to make a
different use of it.
All inquiries or complaints from employees concerning the subject matter or application of this
section shall be referred directly to the Union for investigation and review. The Union shall screen
and thereafter shall present only those inquiries or complaints which it believes are justified to the
Commanding Officer of the Office of Labor Relations of the Police Department, or the Commanding
Officer's designee, for discussion and possible adjustment.
This Section shall not be subject to the grievance procedure.
Section 3. - Maintenance of Facilities
All commands and other Departmental places of assignment shall have adequate heating, hot water
and sanitary facilities. The Union shall give notice to the Department of any failure to maintain these
conditions. If not corrected by the Department within a reasonable time, the Union may commence a
grievance at Step 3 of the grievance procedure concerning that failure.
Section 4. - Private Hospital Accommodations for Line-of-Duty Injuries
It is the intent of the City to use its best efforts to secure private room accommodations in a hospital
for employees injured in the line of duty. This Section shall not be subject to the grievance
procedure.
Section 5. - Information Exchange
a.
The Department will provide the Union with a copy of all Orders, Department Bulletins,
"Open Door" issues, and press releases. The details of delivery shall be worked out between
the parties.
The Department will provide to the Union on a semi-annual basis a computer printout
containing names and addresses of employees, listed alphabetically.
b.
The Union will provide the Department with a copy of Union publications, bulletins and
press releases.
2009-2011 LBA
17

<a id="page-19"></a>
## Page 19  ·  _OCR-reconstructed_

Section 6. - Meal Areas
A representative of the Department and a representative of the LBA will meet to determine an
adequate meal area for employees within each command and other Departmental places of
assignment. This does not contemplate rebuilding or extensive remodeling.
Section 7. - Personal Folder
a.
The Personnel Bureau will provide the Union with a list of categories of items included in
the Personal Folder with an indication of those confidential items which an employee is not
permitted to review.
b.
Employees may view their folders on normal business days between the hours of 9 A.M. and
5 P.M. by appearing in person at the Employee Management Division, Personnel Bureau,
10th Floor, Police Headquarters. To avoid delay, employees should call the Employee
Management Division at least one day in advance.
C.
The Department will upon written request to the Chief of Personnel by the individual
employee, remove from the Personnel Folder investigative reports which, upon completion
of the investigation are classified "exonerated" and/or "unfounded".
Section 8. - Disciplinary Records
Where an employee has been charged with a "Schedule A" violation as listed in Patrol Guide 206-3
and such case is heard in the Trial Room and disposition of the charge at trial or on review or appeal
therefrom is other than "guilty", the employee concerned may, after 2 years from such disposition,
petition the Police Commissioner for a review for the purpose of expunging the record of the case.
Such review will be conducted by a board composed of the Deputy Commissioner - Trials,
Department Advocate, and the Chief of Personnel, or their designees. The Board will make a
recommendation to the Police Commissioner. The employee concerned will be notified of the final
decision of the Police Commissioner by the Deputy Commissioner - Trials.
Section 9. - Disciplinary Procedures
The parties, through a joint subcommittee, shall develop procedures to insure that:
a.
All disciplinary charges shall be brought in a timely fashion pursuant to the current
departmental regulations.
b.
Departmental trials shall be held as promptly as possible, utilizing additional hearing
personnel.
2009-2011 LBA
18

<a id="page-20"></a>
## Page 20  ·  _OCR-reconstructed_

c.
Reimbursement shall be made for any period of suspension in excess of any penalty
ultimately levied.
Section 10. - Fixed Post Duty
A commanding officer may limit fixed post duty for a single employee to a single four-hour period.
Section 11. - Meal Scheduling
Employees shall not be assigned meals as a matter of practice during either the first hour and
one-half or last hour and one-half of their tours. In cases of emergency this practice may be altered.
Section 12. - Lump Sum Payments
Where an employee has an entitlement to accrued annual leave and/or compensatory time, and the
City's fiscal condition requires employees who are terminated, laid off or who choose to retire in lieu
of layoff to be removed from the payroll on or before a specific date, or where an employee reaches
the mandatory retirement age, the employer shall provide the monetary value of accumulated and
unused annual leave and/or compensatory time allowances standing to the employee's credit in a
lump sum. Such payment shall be in accordance with the provisions of Executive Order 30, dated
June 24, 1975.
Where an employee has an entitlement to terminal leave and the City's fiscal situation requires that
employees who are terminated, laid off or retired be removed from the payroll on or before a specific
date, or where an employee reaches the mandatory retirement age, the employer shall provide a
monetary lump sum payment for terminal leave in accordance with the provisions of Executive
Order 31, dated June 24, 1975.
Section 13. - Interest Payments
Interest on wage increases shall accrue at the rate of three percent (3%) per annum from one
hundred-twenty (120) days after execution of this Agreement or one hundred-twenty (120) days after
the effective date of the increase, whichever is later, to the date of actual payment. Interest on
longevity and step-up increments, differentials and holiday pay shall accrue at the rate of three
percent (3%) per annum from one hundred-twenty (120) days following its earning or one
hundred-twenty (120) days after the execution of this Agreement, whichever is later, to the date of
actual payment. Interest on overtime pay shall accrue at the rate of three percent (3%) per annum
from one hundred-twenty (120) days following its earning or one hundred-twenty (120) days
following the employee's submission of an overtime report, whichever is later. Interest accrued
pursuant to this paragraph shall be payable only if the amount of interest due to an individual
employee exceeds five dollars ($5).
2009-2011 LBA
19

<a id="page-21"></a>
## Page 21  ·  _OCR-reconstructed_

Section 14. - Public Transportation
The City and the LBA will use their best efforts to effect free transportation on buses and subways
for lieutenants.
Section 15. - Polygraphs
The current practice concerning the use of polygraphs in internal investigations shall be maintained
during the term of this Agreement.
Section 16. - Probationary Period
Upon an employee's satisfactory completion of six (6) months of probation, the employee's
commanding officer may recommend that the employee be granted permanent status.
Section 17 - Performance Compensation
The City acknowledges that each of the uniformed forces performs an important service that reflects
the diverse missions of the City's uniformed agencies. In order to reward service of an outstanding,
exceptional nature, each of the uniformed agencies will establish a performance compensation
program to recognize and reward such service, tailored to the unique missions of the individual
uniformed agency.
The parties agree that additional compensation may be paid to employees performing outstanding,
exemplary, difficult and/or unique assignments. The City will notify and discuss with each affected
union of its intent to pay such additional compensation and the individuals to be compensated.
The criteria for the granting of performance-based compensation shall be based upon outstanding
performance in the work assigned, and/or performance of unique and difficult work.
The performance-based compensation payments provided for in this section shall be one-time, non-
recurring cash payments subject to applicable pension law. An employee can receive no more than
one payment annually.
This provision shall not affect any existing productivity programs covered in any existing collective
bargaining agreements. Nor shall this provision be construed to waive any obligation of the City to
negotiate over future productivity programs as required by applicable law.
2009-2011 LBA
20

<a id="page-22"></a>
## Page 22  ·  _OCR-reconstructed_

ARTICLE XVII - UNION ACTIVITY
Section 1.
Time spent by Union officials and representatives in the conduct of labor relations shall be governed
by the provisions of Mayor's Executive Order No. 75, as amended, dated March 22, 1973, or any
other applicable Executive Order or local law, or as otherwise provided in this Agreement. No
employee shall otherwise engage in Union activities during the time the employee is assigned to the
employee's regular duties.
Section 2.
LBA Trustees and delegates shall be recognized as representatives of the LBA within their respective
territories and commands. For the purpose of attending the regular scheduled monthly delegate
meetings, but not more than twelve (12) per year, there will be a 24-hour excusal for daytime
meetings on the 1st, 2nd and 3rd platoons on the day of the meeting, and for evening meetings on the
2nd and 3rd platoons on the day of the meeting and the 1st platoon on the following day. If the
delegate or officer is either sick or out-of-town on leave or assignment, or is required to appear in
court, an alternate will be able to obtain this same excusal. The Union will provide the City with a
list of those attending each such meeting, which shall be the basis for their payment.
Section 3.
The parties shall explore a further clarification of Departmental rules and procedures to enable LBA
delegates and officers to represent properly the interests of Lieutenants.
An appropriate
Departmental order in this regard shall be issued.
ARTICLE XVIII - NO DISCRIMINATION
In accord with applicable law, there shall be no discrimination by the City against any employee
because of Union activity.
a.
b.
ARTICLE XIX - NIGHT SHIFT DIFFERENTIAL
There shall be a 10% night shift differential effective January 1, 1971 applicable to all
employees assigned to rotating tours of duty for all work actually performed between the
hours of 4:00 P.M. and 8:00 A.M. There shall be a 10% night shift differential effective
January 1, 1971 applicable to all other employees for all work actually performed between
the hours of 4:00 P.M. and 8:00 A.M., provided that more than one hour is actually worked
after 4:00 P.M. and before 8:00 A.M.
Where overtime compensation is to be calculated for tours in the regular duty chart, the
overtime calculation shall be based on the rate paid for the tour to which the overtime is
2009-2011 LBA
21
090
1 5

<a id="page-23"></a>
## Page 23  ·  _OCR-reconstructed_

attached; for tours not in the regular duty chart, the overtime calculation shall be based on the
rate paid for half or more of the hours of the tour to which the overtime is attached.
ARTICLE XX - OVERTIME TRAVEL GUARANTEE
Section 1.
The assignment of an employee to a post not within the employee's permanent command (hereinafter
referred to as "flying") shall in the first instance be accomplished so that the assignment originates
and terminates within such employee's permanent command and within the employee's regular tour
of duty.
Section 2.
Overtime travel guarantee compensation shall continue to be paid as follows:
a.
In the event that an employee is assigned to a post outside the employee's permanent
command and is required to report at such post at the start of the employee's regular tour of
duty, the employee shall accrue an allowance for travel to the assigned post at the rate of time
and one-half for 45 minutes of travel time if the assigned post is within the same patrol
borough as the employee's permanent command or at the rate of time and one-half for 1-1/4
hours if the assigned post is in a different patrol borough from that of the employee's
permanent command.
b.
In the event that an employee is assigned to a post outside the employee's permanent
command and cannot return to the permanent command within the regular tour of duty, the
employee shall accrue an allowance for travel to the permanent command at the same rate as
stated in Subsection 2(a) of this Article.
Section 3.
The overtime accrued pursuant to this Article for any one day shall be taken at the employee's sole
option either all in cash or all in compensatory time off.
Section 4.
Notwithstanding anything to the contrary herein, employees assigned to the Detective Bureau and/or
"Designated as Commander of Detective Squad" and/or "Designated on Special Assignment" shall
not receive Overtime Travel Guarantee compensation during the entire period of such assignment,
except when assigned in uniform.
2009-2011 LBA
22

<a id="page-24"></a>
## Page 24  ·  _OCR-reconstructed_

ARTICLE XXI - GRIEVANCE AND ARBITRATION PROCEDURE
Section 1. - Definitions
a.
b.
c.
e.
For the purposes of this Agreement the term, "grievance," shall mean:
(1)
a claimed violation, misinterpretation or inequitable application of the provisions of
this Agreement;
(2)
a claimed violation, misinterpretation or misapplication of the rules, regulations, or
procedures of the Police Department affecting terms and conditions of employment,
provided that, except as otherwise provided in this Section 1(a), the term, grievance"
shall not include disciplinary matters;
(3)
a claimed improper holding of an open-competitive rather than a promotional
examination;
(4)
a claimed assignment of the grievant to duties substantially different from those
stated in the grievant's job title specifications.
For the purposes of this Agreement the term "Commanding Officer" shall mean the
immediate Commanding Officer of the aggrieved employee.
For the purposes of this Agreement the term "Reviewing Officer" shall mean the superior
officer in charge of the next higher command or level above a Commanding Officer.
For the purposes of this Agreement the term "Board shall mean the Personnel Grievance
Board to be composed of three (3) members, as follows: a Deputy Commissioner or other
designee of the Police Commissioner, who shall be Chairman of the Board, the Chief of
Department or the Chief of Department's designee, and the President of the Union or the
President's designee.
For the purposes of this Agreement the term, grievant, shall mean an employee or group of
employees asserting a grievance or the Union or both, as the context requires.
Section 2.
The availability of the grievance or arbitration procedure shall not justify a failure to follow orders.
2009-2011 LBA
23

<a id="page-25"></a>
## Page 25  ·  _OCR-reconstructed_

Section 3.
a.
Every grievant shall have the right to present a grievance in accord with the procedure
provided herein free from coercion, interference, restraint or reprisal.
b.
The informal resolution of differences or grievances is urged and encouraged at all levels of
supervision.
c.
Commanding Officers and Reviewing Officers shall promptly consider grievances presented
to them and, within the scope of their authority take such necessary action as is required
herein.
d.
Commanding Officers, Reviewing Officers and members of the Personnel Grievance Board
shall consider objectively the merits of grievances with due consideration to the harmonious
interrelationship that is sought to be achieved among all members of the force and for the
good of the Police Department.
Any employee may present the employee's own grievance through the first four steps of the
grievance procedure either individually (with the aid of the employee's own counsel if the
employee so chooses), or through the Union, provided, however, that the Union shall have
the right to have a representative present at each step of the grievance procedure.
Section 4.
Under the grievance procedure herein a grievance must be initiated within 90 days following the date
on which the grievance arose or the date on which the grievant should reasonably have learned of the
grievance or the execution date of this Agreement, whichever date is the latest. Grievances shall be
processed according to the following procedure:
STEP L
A grievant shall present the grievance to the Commanding Officer either orally or in writing. The
Commanding Officer shall carefully consider the matter, make a decision thereon and advise the
grievant of the decision within five (5) days of the grievance's submission.
STEP II.
If the grievance is not satisfactorily adjusted at Step I, the grievant may seek the following review
within ten days after receipt of the Step I decision. The grievant shall reduce the grievance to writing
on Form P.D. 158-151 (in triplicate), setting forth a concise statement of the grievance and the
results of the proceedings at Step I. The grievant shall forward two copies to the appropriate
Reviewing Officer and retain one copy for personal use. The Reviewing Officer shall forward one
copy to the Commanding Officer, requesting the Commanding Officer's comments. The Reviewing
Officer shall carefully consider said grievance, make a determination, and notify the grievant and the
2009-2011 LBA
24

<a id="page-26"></a>
## Page 26  ·  _OCR-reconstructed_

Commanding Officer of the Reviewing Officer's decision within ten (10) days following receipt of
the grievance.
STEP III.
If the grievance is still not satisfactorily adjusted, the grievant may, not later than ten days after
notification of the Reviewing Officer's decision, seek further review as follows:
The grievant shall prepare a report on P.D. 158-151 (in quintuplicate) setting forth a concise
statement of the grievance and the results of the proceedings at Steps I and II. The grievant shall
forward four copies of the report through official channels to the Chairman, Personnel Grievance
Board, retaining one copy for personal use. The Board shall forward one copy to the Reviewing
Officer, requesting the Reviewing Officer's comments thereon. The Personnel Grievance Board
shall meet at least once a month on a date designated by the Chairman. At each meeting, the Board
shall consider all grievances which, at least five days prior to such meeting, have been properly
referred to the Board. The grievant may choose to have the grievant's representatives present at the
meeting, at which time oral and written statements may be presented.
The Board shall carefully consider said grievance, make a determination and notify the grievant, the
Commanding Officer and the Reviewing Officer, in writing, of its decision within seven days after
the meeting at which the grievance is considered.
It is understood and agreed by and between the parties that there are certain grievable disputes which
are of a Department level or of such scope as to make adjustments at Step I or Step Il of the
grievance procedure impracticable, and, therefore, such grievances may be instituted at Step III of the
grievance procedure by filing the required written statement of the grievance directly with the
Chairman of the Personnel Grievance Board; the Chairman or Chairman's designee shall convene a
meeting of the Board within five (5) working days following receipt of the grievance, and the Board
shall render its decision within five (5) working days following that meeting.
STEP TV.
Where the grievance is not satisfactorily adjusted at Step III, the grievant may refer the grievance, not
later than thirty (30) calendar days after notification of the Board's decision, to the Police
Commissioner for determination; and the Police Commissioner shall make a determination within
ten (10) working days following receipt of the grievance. This determination shall be made after
appropriate consultation with any or all parties to the grievance, including the Chairman of the Board
and/or the Board members; and copies shall be sent to the grievant and the Union.
Grievances which affect substantial numbers of employees may be compressed by elimination of the
fourth Step of the grievance procedure.
2009-2011 LBA
25
09011

<a id="page-27"></a>
## Page 27  ·  _OCR-reconstructed_

Section 5.
At every step of these procedures, the grievant and the officer considering the grievance shall work
for a satisfactory adjustment. At any step, the Commanding Officer, the Reviewing Officer, and the
Board shall have the right to summon the grievant and any and all persons considered necessary to
the equitable adjustment of the grievance. Proceedings shall be informal. The Chairman of the
Personnel Grievance Board shall take such steps to implement the provisions concerning grievances
as are necessary for the proper and effective operation of the procedures provided for herein. The
Chairman shall resolve questions as to jurisdictional responsibility of Commanding Officers and
Reviewing Officers and shall work out the operational details of the program. For these purposes,
the Chairman shall issue orders and instructions through the Chief of Department not inconsistent
with the provisions of this Article.
Section 6.
The grievance procedure established hereinbefore is designed to operate within the framework of,
and is not intended to abolish or supersede, existing rules and procedures providing for additional
methods of redress. These include, but are not limited to, the existing rights of a grievant to request
an interview with the Police Commissioner.
Section 7.
Any or all of the foregoing grievance steps may be waived by the written consent of both parties.
Section 8.
Within twenty (20) days following receipt of the Police Commissioner's Step IV decision, the Union
shall have the right to bring grievances unresolved at Step IV to impartial arbitration pursuant to the
New York City Collective Bargaining Law and the Consolidated Rules of the New York City Office
of Collective Bargaining. In addition, upon ten (10) days' written notice to the Union, the City shall
have the right to bring directly to arbitration any dispute between the parties concerning any matter
defined as a "grievance" herein. The City shall commence such arbitration by submitting a written
request therefor to the Office of Collective Bargaining, with a copy to the Union; and the matter shall
proceed pursuant to the Consolidated Rules of the Office of Collective Bargaining.
A permanent rotating Panel of three (3) Arbitrators shall be established, drawn from the official
panel of the Office of Collective Bargaining, as agreed to by both parties. The members of the Panel
shall be assigned on a rotating basis to arbitrate all grievances under this Section.
The assigned Arbitrator shall hold a hearing at a time and place convenient to the parties and a
transcript shall be taken unless the taking of a transcript is waived by both parties. The arbitrator
shall attempt to issue an award within ten (10) days after the completion of the hearing.
2009-2011 LBA
26

<a id="page-28"></a>
## Page 28  ·  _OCR-reconstructed_

The City and the Union shall each pay 50% of the fees and expenses of the Arbitrator and of all other
expenses incidental to such arbitration. The costs of one copy for each party and one copy for the
Arbitrator of the transcripts shall be borne equally by the parties.
Section 9.
In case of grievances talling within Sections 1(a)(1) or 1(a)(2) of this Article, the arbitrator's
decision, and order or award (if any), shall be limited to the application and interpretation of the
collective bargaining Agreement, rule, regulation, procedure, order or job title specification involved,
and the Arbitrator shall not add to, subtract from, or modify any such Agreement, rule, regulation,
procedure, order or job title specification. An Arbitrator's award shall be final and binding and
enforceable in any appropriate tribunal in accord with Article Seventy-Five of the Civil Practice Law
and Rules, except that awards as to grievances concerning assignment of the grievant to duties
substantially different from those stated in the grievant's job title specification or the use of an
open-competitive rather than promotional examination, shall be final and binding and enforceable
only to the extent permitted by law. An Arbitrator may provide for and direct such relief as the
Arbitrator determines to be necessary and proper, subject to the limitation set forth above and any
applicable limitations of law.
Section 10.
The time limits contained in this Article may be modified by mutual agreement. In the event that the
Department fails to comply with the time limits prescribed herein, the grievance may be advanced to
the next step.
ARTICLE XXII - LINE-OF-DUTY DEATH BENEFIT
In the event an employee dies because of a line-of-duty injury received during the actual and proper
performance of police service relating to the alleged or actual commission of an unlawful act, or
directly resulting from a characteristic hazard of police duty, through no fault of the employee's, a
payment of $25,000 shall be made from funds other than those of the Retirement System in addition
to any other payment which may be made as a result of such death. Such payment shall be made to
the beneficiary designated under the Retirement System or, if no beneficiary is so designated, to the
estate of the deceased.
ARTICLE XXIII - DEATH BENEFIT-UNUSED LEAVE AND
COMPENSATORY TIME
If an employee dies while employed by the City, the employee's beneficiary designated under the
Retirement System or, if no beneficiary is so designated, the deceased's estate shall receive payment
in cash for the following as a death benefit:
2009-2011 LBA
27

<a id="page-29"></a>
## Page 29  ·  _OCR-reconstructed_

a.
b.
All unused accrued leave up to a maximum of 54 days' credit;
All unused accrued compensatory time earned subsequent to January 1, 1971 which is
verifiable by official Department records up to a maximum of two hundred (200) hours.
ARTICLE XXIV - OPTIONAL WORK DURING VACATIONS
Section 1.
Any employee may volunteer to work for one five-day period during such employee's vacation leave.
Whether the volunteer will be assigned to duty is within the discretion of the Department. If
assigned to duty, the assignment shall be at the discretion of the Department to any regular platoon in
any one command for the entire five-day period. No employee shall be discriminated against in the
application of this Section because the employee is in the last year of service.
Section 2.
An employee who so volunteers shall be compensated at the employee's regular straight-time rate of
pay for all work performed during the assigned platoon's regular hours of work. Except as otherwise
provided in this Article, all other provisions of this Agreement shall be applicable to work so
performed.
Section 3.
Contributions under Article XII (Health and Welfare Fund) and Article XIV (Annuity Fund) of this
Agreement shall not be paid for work performed pursuant to this Article.
Section 4.
For the purposes of Article XX (Overtime Travel Guarantee) of this Agreement, the command to
which an employee is so assigned for the five-day period shall be deemed that employee's
"permanent command."
ARTICLE XXV - NO STRIKES
In accord with applicable law, neither the Union nor any employee shall induce or engage in any
strikes, slowdowns, work stoppages, or mass absenteeism, or induce any mass resignations during
the term of this Agreement.
2009-2011 LBA
28

<a id="page-30"></a>
## Page 30  ·  _OCR-reconstructed_

ARTICLE XXVI - EMPLOYEES SPECIALLY ASSIGNED OR
DESIGNATED
Notwithstanding anything to the contrary contained in this agreement, employees assigned to the
Detective Bureau and/or "Designated as Commander of the Detective Squad" and/or "Designated on
Special Assignment" shall be eligible for the receipt of benefits under this Agreement in the same
manner and under the same circumstances as Members of the Force detailed as First, Second and
Third Grade Detectives.
ARTICLE XXVII - BULLETIN BOARDS
The Union may post notices on bulletin boards in places and locations where notices usually are
posted by the employer for employees to read. All notices shall be on Union stationery, shall be used
only to notify employees of matters pertaining to Union affairs, and shall not contain any derogatory
or inflammatory statements concerning the City, the Department, or personnel employed by either
entity.
ARTICLE XXVIII - NO WAIVER
Except as otherwise provided in this Agreement, the failure to enforce any provision of this
Agreement shall not be deemed a waiver thereof. This Agreement is not intended and shall not be
construed as a waiver of any right or benefit to which employees are entitled by law.
ARTICLE XXIX - SAVINGS CLAUSE
If any provision of the Agreement is found to be invalid, such invalidity shall not impair the validity
and enforceability of the remaining provisions of this Agreement.
ARTICLE XXX - LABOR MANAGEMENT COMMITTEE
Section 1.
The City and the Union, having recognized that cooperation between management and employees is
indispensable to the accomplishment of sound and harmonious labor relations, shall jointly maintain
and support a labor-management committee.
Section 2.
The labor-management committee shall consider and may recommend to the Police Commissioner
changes in the working conditions of the employees, including, but not limited to, the following
subjects: the adequate levels of police coverage to ensure the safety of employees on duty; and
excusal policy for employees appearing in court after the midnight tour. Matters subject to the
2009-2011 LBA
29

<a id="page-31"></a>
## Page 31  ·  _OCR-reconstructed_

grievance procedure shall not be appropriate items for consideration by the labor-management
committee.
Section 3.
The labor-management committee shall consist of six members who shall serve for the term of this
Agreement. The Union shall designate three members and the Police Commissioner shall designate
three members. Vacancies shall be filled by the appointing party for the balance of the term to be
served. Each member may designate one alternate. The committee shall select a chairman from
among its members at each meeting. The chairmanship of the committee shall alternate between
members designated by the Police Commissioner and the members designated by the Union. A
quorum shall consist of a majority of the total membership of a committee. A committee shall make
its recommendations to the Police Commissioner in writing.
At the request of either the Police Department or the L.B.A., a representative of the Mayor's Office
of Labor Relations will sit in on the Labor Management Committee.
Section 4.
The labor-management committee shall meet at the call of either the Union members or the City
members at times mutually agreeable to both parties. At least one week in advance of a meeting the
party calling the meeting shall provide to the other party, a written agenda of matters to be discussed.
Minutes shall be kept and copies supplied to all members of the committee.
ARTICLE XXXI - FINANCIAL EMERGENCY ACT
The provisions of this Agreement are subject to applicable provisions of law including the New York
State Financial Emergency Act for the City of New York, as amended.
ARTICLE XXXII - TERM
The term of this Agreement shall commence on November 1, 2009 and shall expire at midnight on
October 31, 2011.
2009-2011 LBA
30

<a id="page-32"></a>
## Page 32  ·  _OCR-reconstructed_

IN WITNESS WHEREOF
, the parties have executed this here em on the S
day and year first above written.
CITY OF NEW YORK
LIEUTENANTS' BENEVOLENT
ASSOCIATION OF THE CITY OF
NEW YORK
BY
BY
JAMES F. HANLEY
Commissioner
Labor Relations
Thomas
Sullivan
THOMAS SULLIVAN
President
APPROVED AS TO FORM:
OFFICE OF LABOR RELATIONS
REGISTRATION
BY
Sila
PAUL T. RERHEN
Acting Corporation Counsel
OFFICIAL
CONTRACT
DATE SUBMITTED TO THE
FINANCIAL CONTROL BOARD:
NO:
09011
DATE:
FEB 0 2 2009
UNIT: LIEUTENANTS
TERM: November 1, 2009 to October 31, 2011
2009-2011 LBA

<a id="page-33"></a>
## Page 33  ·  _OCR-reconstructed_

DEP
THE POLICE COMMISSIONER
CITY OF NEW YORK
March 23, 2009
Lieutenant Thomas Sullivan
Lieutenants Benevolent Association
233 Broadway - Suite 1801
New York, New York 10279
Re: LBA AGREEMENT FOR THE PERIOD
SEPTEMBER 1, 2007 TO OCTOBER 31, 2011
Dear Lieutenant Sullivan,
A representative of the Lieutenants Benevolent Association shall be a member of the
Disciplinary Advisory Labor Management Committee established to review the existing
disciplinary process of the Police Department, in addition to the Police Benevolent Association
(PBA) representative, the Deputy Commissioner of Trials, the Department Advocate and the
Deputy Commissioner of Labor Relations. The Committee shall make recommendations to the
Police Commissioner on the operation of the disciplinary machinery.
Sincerely,
Raymond W. Kelly
Police Commissioner
1 Police Plaza, New York, NY 10038 • 646-610-5410 • Fax: 646-610-5865
Website: http://nyc.gov/nypd

<a id="page-34"></a>
## Page 34  ·  _OCR-reconstructed_

POLICE
DEP
THE POLICE COMMISSIONER
CITY OF NEW YORK
YORK
CITY
March 23, 2009
Lieutenant Thomas Sullivan
Lieutenants Benevolent Association
233 Broadway - Suite 1801
New York, New York 10279
Re:
LBA AGREEMENT FOR THE PERIOD
SEPTEMBER 1, 2007 TO OCTOBER 31, 2011
Dear Lieutenant Sullivan,
Please be advised that the Police Department will fill permanent vacancies where they
exist in the Patrol Precinct Desk assignments from the Borough Replacement Lieutenants
assigned within the borough. This shall not be subject to the grievance procedure.
In addition, it is the intent of the Department, if possible, to give a Borough
Replacement Lieutenant seventy-two (72) hours notice prior to rescheduling his tour of duty.
This shall not be subject to the grievance procedure.
Sincerely,
Police Commissioner.
Mond W. Kelly
1 Police Plaza, New York, NY 10038 • 646-610-5410 • Fax: 646-610-5865
Website: http://nyc.gov/nypd

<a id="page-35"></a>
## Page 35  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
MARGARET M. CONNOR
First Deputy Commissioner
Lieutenant Thomas Sullivan, President
Lieutenants Benevolent Association
233 Broadway - Suite 850
New York, New York 10279
Re: LBA Agreement for the period
November 1, 2009 to October 31, 2011
Dear Lieutenant Sullivan:
A Committee will be constituted of eight persons, four appointed by the City and four by
the LBA, to survey the availability of parking locations in the vicinity of station houses.
This Committee shall report within 90 days after ratification of the above Agreement
which report shall make recommendation to increase the availability of parking spaces if
that result is legally permissible and administratively possible.
Very truly yours,
Fame I Shaley
James F. Hanley
2009-2011 LBA

<a id="page-36"></a>
## Page 36  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
MARGARET M. CONNOR
First Deputy Commissioner
Lieutenant Thomas Sullivan, President
Lieutenants Benevolent Association
233 Broadway - Suite 850
New York, New York 10279
Re: LBA Agreement for the period
November 1, 2009 to October 31, 2011
Dear Lieutenant Sullivan:
Lieutenants assigned to Patrol Precinct and Highway Unit desk duty shall be scheduled to
work 243.33 tours of duty a year consisting of 8 hour and 35 minute tours.
Lieutenants assigned to the Patrol Boroughs performing duty as borough replacement for
Patrol Precinct and Highway Unit desk officers (Replacement Lieutenants") shall also
perform 243.33 - 8 hour and 35 minute tours. Article III, 1b and Article XXI shall not be
applicable to these "Replacement Lieutenants."
Borough Lieutenants rescheduled for other than desk duty assignments shall receive the
Overtime Travel Guarantee where appropriate.
Effective August 1, 2006, as a result of the 2003-07 collective bargaining agreement, all
employees shall work an additional ten (10) minutes per tour.
Very truly yours,
James Harley
James F. Hanley
2009-2011 LBA

<a id="page-37"></a>
## Page 37  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
MARGARET M. CONNOR
First Deputy Commissioner
Lieutenant Thomas Sullivan, President
Lieutenants Benevolent Association
233 Broadway - Suite 850
New York, N.Y. 10279
Re: LBA Agreement for the period November 1, 2009 to October 31, 2011
Dear Lieutenant Sullivan:
This is to confirm our mutual understanding and agreement regarding the increased number
of appearances required by certain Lieutenants as follows:
A. Effective July 1, 1990, as a result of the 1987-90 collective bargaining agreement, each
employee shall be required to work two (2) additional tours beyond the number currently
required.
Each employee promoted to Lieutenant on or after July 1, 1990 shall be required to work
three (3) additional tours per year beyond the number required for a similarly situated
incumbent Lieutenant.
B. Effective July 1, 1995, as a result of the 1992-95 collective bargaining agreement, the
following shall apply to each employee promoted to Lieutenant on or after July 1, 1990:
After serving five (5) years in the rank of Lieutenant, employees shall be required to work
two (2) additional tours per year beyond the number required for a similarly situated
incumbent Lieutenant promoted prior to July 1, 1990. After serving six (6) years in the rank
of Lieutenant, employees shall be required to work one (1) additional tour per year beyond
the number required for a similarly situated incumbent Lieutenant promoted prior to July 1,
1990. After serving seven (7) years in the rank of Lieutenant, employees shall work the same
number of tours per year as a similarly situated incumbent Lieutenant promoted prior to July
1, 1990.
2009-2011 LBA

<a id="page-38"></a>
## Page 38  ·  _OCR-reconstructed_

C. Effective August 1, 2006, pursuant to the 2003-07 collective bargaining agreement, the
following shall apply:
In addition to the above number of additional tours required to be worked, all employees
promoted on or after August 1, 2006 shall be required to forego an additional thirteen (13)
chart days per year for seven (7) years. After serving seven (7) years in the rank of
Lieutenant, employees shall work the same number of tours per year as a similarly situated
incumbent Lieutenant promoted prior to August 1, 2006.
D. Effective October 1, 2008, the following shall replace section C above:
In addition to the above number of additional tours required to be worked, employees
promoted on or after August 1, 2006 shall be required to forego an additional 13 chart days
per year for the first two years in the rank of Lieutenant, and additional 12 per year in the 3rd
year, and an additional 11 per year in years 4 through 7. After serving seven years in the
rank of Lieutenant, employees shall work the same number of tours per year as a similarly
Very truly yours,
James F. Hanley
ne I Nanley
2009-2011 LBA

<a id="page-39"></a>
## Page 39  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
MARGARET M. CONNOR
First Deputy Commissioner
Lieutenant Thomas Sullivan, President
Lieutenants Benevolent Association
233 Broadway
New York, N.Y. 10279
Re: LBA Agreement for the period
November 1, 2009 to October 31, 2011
Dear Lieutenant Sullivan:
This is to confirm our mutual understanding and agreement regarding Article XIII of the
above Agreement. If the stabilization fund referred to does not have sufficient monies to
maintain the then current level of health insurance benefits provided under
GHI-CBP/Blue Cross plan, payroll deductions in the appropriate amounts shall be taken
from employees and retirees enrolled in such plan unless agreement is reached on a
program wide basis to take the needed monies from the contributions to the welfare fund
provided in Article XII of the above Agreement.
Very truly yours,
me I. Henley
James F. Hanley
AGREED AND ACCEPTED ON BEHALF OF THE LBA
BY:
Thomas Sullivan
Thomas Sullivan
2009-2011 LBA

<a id="page-40"></a>
## Page 40  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
MARGARET M. CONNOR
First Deputy Commissioner
Lieutenant Thomas Sullivan
President
Lieutenants Benevolent Association
233 Broadway
New York, N.Y. 10279
Re:
LBA Agreement for the period
November 1, 2009 to October 31, 2011
Dear Lieutenant Sullivan:
This is to confirm our mutual understanding and agreement that the Lieutenants
Benevolent Association (LBA) has accepted and agreed to be bound by the terms of the
2000-2003 LBA Agreement. It is understood that up to $25 per each active employee
per year to be allocated as a "Civil Legal Representation Fund" by the employer is
subject to further discussions. The contributions which are provided could be for
benefits other than civil legal representation expenses and if so, are subject to the
employer's agreement.
These funds shall be administered by the applicable welfare fund; they are to be
maintained in a separate account and shall not be commingled with the other monies
received by the welfare fund.
Very truly yours,
fames 3. Inly
James F. Hanley
2009-2011 LBA

<a id="page-41"></a>
## Page 41  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
MARGARET M. CONNOR
First Deputy Commissioner
Lieutenant Thomas Sullivan, President
Lieutenants Benevolent Association
233 Broadway
New York, N.Y. 10279
Re: LBA Agreement for the period
November 1, 2009 to October 31, 2011
Dear Lieutenant Sullivan:
The City and the LBA recognize that, pursuant to Administrative Code Section 12-127,
the City is obligated to pay for the cost of line of duty injury prescription drugs for LBA
members. The parties further recognize that a significant number of LBA members have
utilized the LBA Health and Welfare Fund to pay for these prescription drugs without
reimbursement by the City. The LBA agrees to waive any and all claims retroactively
and prospectively against the City for the reimbursement of the cost of line of duty
injury prescription drugs.
If the above conforms to your understanding, please execute the signature line below.
Very truly yours,
Jame I Harley
James F. Hanley
AGREED AND ACCEPTED ON BEHALF OF LBA
BY
Thomas Sullivan
Thomas Sullivan
2009-2011 LBA

<a id="page-42"></a>
## Page 42  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
MARGARET M. CONNOR
First Deputy Commissioner
Lieutenant Thomas Sullivan, President
Lieutenants Benevolent Association
233 Broadway
New York, N.Y. 10279
Re: LBA Agreement for the period
November 1, 2009 to October 31, 2011
Dear Lieutenant Sullivan:
This is to confirm that during negotiations for the successor agreement to this 2009-2011 agreement the
parties shall negotiate the issue of increasing the City's contribution to the LBA Health and Welfare
Fund as the first issue to be addressed. The issues to be negotiated shall include the intent of the parties
to equalize the City's total contribution to the LBA Health and Welfare Fund with the total
contributions made by the City to other health and welfare funds on behalf of other employees and that
the LBA shall be responsible for the cost of such increased contributions.
If the above conforms to your understanding, please execute the signature line below.
Very truly yours,
Pees I Sanley
James F. Hanley
AGREED AND ACCEPTED ON BEHALF OF LBA
BY
somas fullivan
Thomas Sullivan
2009-2011 LBA

<a id="page-43"></a>
## Page 43  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
MARGARET M. CONNOR
First Deputy Commissioner
Lieutenant Thomas Sullivan, President
Lieutenants Benevolent Association
233 Broadway
New York, N.Y. 10279
Re: LBA Agreement for the period
November 1, 2009 to October 31, 2011
Dear Lieutenant Sullivan:
Effective 11/1/98, the City shall grant one (1) additional full-time release position. Such additional
release time shall be governed by Executive Order 75 (IEO 75), except insofar as the LBA has funded
the ongoing costs of such additional release time for the term of this agreement and thereafter out of the
settlement costs of a prior collective bargaining agreement and therefore Section 4(1) of EO 75 shall not
apply to this additional release time.
Very truly yours,
fann I Harley
James F. Hanley
AGREED AND ACCEPTED ON BEHALF OF LBA
BY Thomas Sullivan
Thomas Sullivan
2009-2011 LBA
011

<a id="page-44"></a>
## Page 44  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
MARGARET M. CONNOR
First Deputy Commissioner
Lieutenant Thomas Sullivan, President
Lieutenants Benevolent Association
233 Broadway
New York, N.Y. 10279
Re: LBA Agreement for the period
November 1, 2009 to October 31, 2011
Dear Lieutenant Sullivan:
Upon ratification, the Union shall withdraw, with prejudice, the following case(s):
• Failure to implement 12-Hour Tour Pilot Program Improper Practice.
• Failure to implement Night Shift Differential Payment Improper Practice.
(BCB-2633-07)
If the above accords with your understanding, please execute the signature line below.
Very truly yours,
Jame 7 Haley
James F. Hanley
AGREED AND ACCEPTED ON BEHALF OF LBA
BY
Thomas Sullivan
Thomas Sullivan
2009-2011 LBA

<a id="page-45"></a>
## Page 45  ·  _OCR-reconstructed_

THE CITY OF NEW YORK
OFFICE OF LABOR RELATIONS
40 Rector Street, New York, NY 10006-1705
http://nyc.gov/olr
JAMES F. HANLEY
Commissioner
MARGARET M. CONNOR
First Deputy Commissioner
Lieutenant Thomas Sullivan, President
Lieutenants Benevolent Association
233 Broadway
New York, N.Y. 10279
Re: LBA Agreement for the period
November 1, 2009 to October 31, 2011
Dear Lieutenant Sullivan:
This is to confirm our mutual understanding and agreement regarding the length of the tour and the increased
number of appearances required by certain Lieutenants as follows:
Duty Schedules
a.
Effective August 1, 2006, for all new promotees the length of the tour shall be eight hours and forty-five
minutes (8:45), inclusive of the additional time further specified in paragraph c., below.
b.
In addition to the number of additional tours required to be worked pursuant to the 2000-2003 LBA unit
agreement, all employees promoted on or after August 1, 2006 shall be required to forego an additional
thirteen (13) chart days per year for seven (7) years. After serving seven (7) years in the rank of
Lieutenant, employees shall work the same number of tours per year as a similarly situated incumbent
Lieutenant promoted prior to August 1, 2006.
c.
Effective August 1, 2006, all employees shall work an additional ten (10) minutes per tour.
2009-2011 LBA

<a id="page-46"></a>
## Page 46  ·  _OCR-reconstructed_

d.
Effective October 1, 2008, the LBA will buyback one chart day on the third anniversary and one
additional chart day on the fourth anniversary for Lieutenants promoted on or after August 1, 2006.
If the above accords with your understanding, please execute the signature line below.
Very truly yours,
James F. Hanley
AGREED AND ACCEPTED ON BEHALF OF LBA
BY_
omas Sillion
Thomas Sullivan
2009-2011 LBA

---
_End of contract. Source PDF: <https://www.nyc.gov/assets/olr/downloads/pdf/collectivebargaining/cbu59-police-lieutenants-benevolent-association-110109-to-103111.pdf>_
